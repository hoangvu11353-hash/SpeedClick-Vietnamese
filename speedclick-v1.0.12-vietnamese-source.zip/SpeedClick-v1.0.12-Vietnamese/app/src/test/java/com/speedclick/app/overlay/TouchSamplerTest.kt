package com.speedclick.app.overlay

import com.speedclick.app.data.TouchEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TouchSamplerTest {

    private val width = 1080
    private val height = 2400

    private fun sample(
        elapsedMs: Long,
        action: TouchAction,
        actionIndex: Int = 0,
        ids: IntArray = intArrayOf(0),
        xs: FloatArray = floatArrayOf(540f),
        ys: FloatArray = floatArrayOf(1200f),
    ) = TouchSampler.sample(
        elapsedMs = elapsedMs,
        action = action,
        actionIndex = actionIndex,
        pointerIds = ids,
        xs = xs,
        ys = ys,
        screenWidth = width,
        screenHeight = height,
    )

    private fun events(outcome: TouchSampler.Outcome): List<TouchEvent> {
        assertTrue(outcome is TouchSampler.Outcome.Sampled)
        return (outcome as TouchSampler.Outcome.Sampled).events
    }

    @Test
    fun `single tap is normalized and timestamped`() {
        val down = events(sample(120L, TouchAction.DOWN))
        val up = events(sample(180L, TouchAction.UP))

        assertEquals(1, down.size)
        assertEquals(TouchEvent.EventType.DOWN, down[0].type)
        assertEquals(0.5f, down[0].x, 0.0001f)
        assertEquals(0.5f, down[0].y, 0.0001f)
        assertEquals(120L, down[0].t)
        assertEquals(0, down[0].pointer)

        assertEquals(1, up.size)
        assertEquals(TouchEvent.EventType.UP, up[0].type)
        assertEquals(180L, up[0].t)
    }

    @Test
    fun `pointer down records only the new pointer`() {
        val secondDown = events(
            sample(
                elapsedMs = 100L,
                action = TouchAction.POINTER_DOWN,
                actionIndex = 1,
                ids = intArrayOf(0, 1),
                xs = floatArrayOf(300f, 900f),
                ys = floatArrayOf(600f, 600f),
            ),
        )

        assertEquals(1, secondDown.size)
        assertEquals(1, secondDown[0].pointer)
        assertEquals(900f / width, secondDown[0].x, 0.0001f)
    }

    @Test
    fun `pointer up records only the released pointer`() {
        val released = events(
            sample(
                elapsedMs = 150L,
                action = TouchAction.POINTER_UP,
                actionIndex = 0,
                ids = intArrayOf(0, 1),
                xs = floatArrayOf(300f, 900f),
                ys = floatArrayOf(600f, 600f),
            ),
        )

        assertEquals(1, released.size)
        assertEquals(0, released[0].pointer)
        assertEquals(TouchEvent.EventType.UP, released[0].type)
    }

    @Test
    fun `move records every active pointer`() {
        val moves = events(
            sample(
                elapsedMs = 200L,
                action = TouchAction.MOVE,
                ids = intArrayOf(0, 1),
                xs = floatArrayOf(320f, 920f),
                ys = floatArrayOf(640f, 640f),
            ),
        )

        assertEquals(2, moves.size)
        assertEquals(setOf(0, 1), moves.map { it.pointer }.toSet())
        assertTrue(moves.all { it.type == TouchEvent.EventType.MOVE })
    }

    @Test
    fun `cancel releases all pointers`() {
        val released = events(
            sample(
                elapsedMs = 300L,
                action = TouchAction.CANCEL,
                ids = intArrayOf(0, 1),
                xs = floatArrayOf(320f, 920f),
                ys = floatArrayOf(640f, 640f),
            ),
        )

        assertEquals(2, released.size)
        assertTrue(released.all { it.type == TouchEvent.EventType.UP })
    }

    @Test
    fun `coordinates outside the screen are clamped`() {
        val down = events(
            sample(
                elapsedMs = 0L,
                action = TouchAction.DOWN,
                xs = floatArrayOf(-50f),
                ys = floatArrayOf(9999f),
            ),
        )

        assertEquals(0f, down[0].x, 0.0001f)
        assertEquals(1f, down[0].y, 0.0001f)
    }

    @Test
    fun `out of range action index is ignored instead of crashing`() {
        val result = sample(elapsedMs = 10L, action = TouchAction.POINTER_UP, actionIndex = 5)
        assertTrue(events(result).isEmpty())
    }

    @Test
    fun `invalid screen size yields no events`() {
        val outcome = TouchSampler.sample(
            elapsedMs = 10L,
            action = TouchAction.DOWN,
            actionIndex = 0,
            pointerIds = intArrayOf(0),
            xs = floatArrayOf(10f),
            ys = floatArrayOf(10f),
            screenWidth = 0,
            screenHeight = 0,
        )
        assertTrue(events(outcome).isEmpty())
    }

    @Test
    fun `recording over the time budget reports over budget`() {
        val result = sample(elapsedMs = TouchSampler.MAX_RECORD_MS, action = TouchAction.MOVE)
        assertTrue(result is TouchSampler.Outcome.OverBudget)
    }
}
