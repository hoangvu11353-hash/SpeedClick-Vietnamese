package com.speedclick.app.service

import android.content.Intent
import android.graphics.RectF
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.data.PlaybackSpec
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.engine.PlaybackEngine
import com.speedclick.app.overlay.RecorderController
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSystemClock
import java.time.Duration

/**
 * The app's core loop, executed for real: touches recorded through the overlay capture layer
 * are replayed through the accessibility dispatch path at the same screen position.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w411dp-h915dp-xxhdpi")
class RecordReplayRoundTripTest {

    private val app: SpeedClickApp get() = ApplicationProvider.getApplicationContext()

    private val metrics get() = app.resources.displayMetrics

    private lateinit var overlayService: OverlayService
    private lateinit var accessibilityService: ClickerAccessibilityService

    @Before
    fun setUp() {
        RecorderController.cancel()
        RecorderController.clearPending()
        PlaybackEngine.stop()

        overlayService = Robolectric.buildService(OverlayService::class.java).create().get()
        accessibilityService = Robolectric.buildService(ClickerAccessibilityService::class.java).create().get()
        shadowOf(accessibilityService).setCanDispatchGestures(true)
        ClickerAccessibilityService.instance = accessibilityService
    }

    @After
    fun tearDown() {
        PlaybackEngine.stop()
        RecorderController.cancel()
        RecorderController.clearPending()
        ClickerAccessibilityService.instance = null
    }

    private fun field(name: String): Any? =
        OverlayService::class.java.getDeclaredField(name).apply { isAccessible = true }.get(overlayService)

    private fun startRecordingOverlay() {
        overlayService.onStartCommand(
            Intent(app, OverlayService::class.java).setAction(OverlayService.ACTION_RECORD),
            0,
            1,
        )
        shadowOf(Looper.getMainLooper()).idle()
    }

    private fun tapCaptureLayer(x: Float, y: Float) {
        val capture = field("captureView") as? View
        assertNotNull("overlay capture layer must exist while recording", capture)
        val t = SystemClock.uptimeMillis()
        capture!!.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0))
        capture.dispatchTouchEvent(MotionEvent.obtain(t, t + 50, MotionEvent.ACTION_UP, x, y, 0))
    }

    @Test
    fun `recorded tap replays at the same screen position`() {
        startRecordingOverlay()
        RecorderController.start(metrics.widthPixels, metrics.heightPixels)
        shadowOf(Looper.getMainLooper()).idle()

        val targetX = metrics.widthPixels * 0.25f
        val targetY = metrics.heightPixels * 0.75f
        tapCaptureLayer(targetX, targetY)

        RecorderController.stop()
        shadowOf(Looper.getMainLooper()).idle()

        val macro = RecorderController.pendingMacro.value
        assertNotNull("recording must produce a macro", macro)
        assertEquals(2, macro!!.events.size)

        PlaybackEngine.start(
            PlaybackSpec(
                label = macro.name,
                events = macro.events,
                delayMs = 0,
                repeat = 1,
                intervalMs = 0,
                speed = 1f,
                jitterPx = 0f,
            ),
        )
        assertEquals(PlaybackStatus.RUNNING, PlaybackEngine.state.value.status)

        // Drive the shadow clock and complete the dispatched gesture so the engine can finish.
        val deadline = System.currentTimeMillis() + 8_000
        var handled = 0
        while (System.currentTimeMillis() < deadline) {
            ShadowSystemClock.advanceBy(Duration.ofMillis(25))
            val all = shadowOf(accessibilityService).gesturesDispatched
            while (handled < all.size) {
                all[handled].callback().onCompleted(all[handled].description())
                handled++
            }
            if (PlaybackEngine.state.value.status == PlaybackStatus.IDLE &&
                handled >= shadowOf(accessibilityService).gesturesDispatched.size
            ) {
                break
            }
            Thread.sleep(20)
        }

        assertEquals(1, handled)
        assertEquals(PlaybackStatus.IDLE, PlaybackEngine.state.value.status)

        val gesture = shadowOf(accessibilityService).gesturesDispatched.first().description()
        assertEquals(1, gesture.strokeCount)
        val bounds = RectF()
        gesture.getStroke(0).path.computeBounds(bounds, true)

        assertEquals(targetX, bounds.centerX(), 1.5f)
        assertEquals(targetY, bounds.centerY(), 1.5f)
    }
}
