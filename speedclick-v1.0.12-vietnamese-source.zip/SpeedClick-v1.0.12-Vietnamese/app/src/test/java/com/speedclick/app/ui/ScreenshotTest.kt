package com.speedclick.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.content.Context
import android.os.Looper
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.data.Macro
import com.speedclick.app.data.TouchEvent
import com.speedclick.app.ui.theme.SpeedClickTheme
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream

/**
 * Renders the real screens on the JVM and writes PNGs to app/build/reports/screenshots
 * so the layout can be inspected without a device.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w411dp-h915dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ScreenshotTest {

    private val displayMetrics
        get() = ApplicationProvider.getApplicationContext<Context>().resources.displayMetrics

    private val width: Int get() = displayMetrics.widthPixels

    private val height: Int get() = displayMetrics.heightPixels

    private fun viewModel(): MainViewModel {
        val app = ApplicationProvider.getApplicationContext<SpeedClickApp>()
        return MainViewModel(app)
    }

    private fun seedMacros(vm: MainViewModel, count: Int = 3) {
        val events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.5f, 0.5f, 0L, 0),
            TouchEvent(TouchEvent.EventType.MOVE, 0.52f, 0.54f, 120L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.55f, 0.6f, 240L, 0),
        )
        runBlocking {
            repeat(count) { index ->
                val macro = Macro(
                    id = "seed-$index",
                    name = "示例宏 ${index + 1}",
                    createdAt = System.currentTimeMillis() - index * 1000L,
                    durationMs = 240L * (index + 1),
                    events = events,
                )
                vm.importText(com.speedclick.app.data.JsonCodec.encode(macro))
            }
        }
        shadowOf(Looper.getMainLooper()).idle()
    }

    private fun capture(name: String, content: @Composable () -> Unit) {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup()
        val activity = controller.get()
        activity.setContent { SpeedClickTheme { content() } }
        shadowOf(Looper.getMainLooper()).idle()

        val root = activity.window.decorView
        root.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY),
        )
        root.layout(0, 0, width, height)
        shadowOf(Looper.getMainLooper()).idle()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        root.draw(Canvas(bitmap))

        val dir = File("build/reports/screenshots").apply { mkdirs() }
        FileOutputStream(File(dir, "$name.png")).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        controller.pause().stop().destroy()
    }

    @Test
    fun renderHomeScreen() {
        val vm = viewModel()
        capture("home") { HomeScreen(vm, onOpenMacros = {}, onOpenPresets = {}) }
    }

    @Test
    fun renderMainShell() {
        capture("main-shell") { MainScreen() }
    }

    @Test
    fun renderMacrosScreenWithData() {
        val vm = viewModel()
        seedMacros(vm)
        capture("macros") { MacrosScreen(vm) }
    }

    @Test
    fun renderMacrosScreenEmpty() {
        val vm = viewModel()
        capture("macros-empty") { MacrosScreen(vm) }
    }

    @Test
    fun renderPresetsScreen() {
        val vm = viewModel()
        capture("presets") { PresetsScreen(vm) }
    }

    @Test
    fun renderSettingsScreen() {
        val vm = viewModel()
        capture("settings") { SettingsScreen(vm) }
    }
}
