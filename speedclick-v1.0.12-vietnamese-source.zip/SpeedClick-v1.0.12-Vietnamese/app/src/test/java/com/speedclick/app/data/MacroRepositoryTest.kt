package com.speedclick.app.data

import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class MacroRepositoryTest {

    private val app: SpeedClickApp get() = ApplicationProvider.getApplicationContext()

    private val events = listOf(
        TouchEvent(TouchEvent.EventType.DOWN, 0.4f, 0.5f, 0L, 0),
        TouchEvent(TouchEvent.EventType.UP, 0.4f, 0.5f, 60L, 0),
    )

    private fun awaitFile(id: String): File {
        val file = File(File(app.filesDir, "macros"), "$id.json")
        val deadline = System.currentTimeMillis() + 5_000
        while (!file.exists() && System.currentTimeMillis() < deadline) Thread.sleep(20)
        return file
    }

    @Test
    fun `saved macro survives a reload from disk`() {
        val repository = MacroRepository(app)
        val macro = repository.save(events, "连点测试")

        val file = awaitFile(macro.id)
        assertTrue("macro file must be written", file.exists())

        val reloaded = MacroRepository(app).loadAll().firstOrNull { it.id == macro.id }
        assertEquals("连点测试", reloaded?.name)
        assertEquals(events, reloaded?.events)
        assertEquals(60L, reloaded?.durationMs)
    }

    @Test
    fun `deleting a macro removes it from disk and from state`() {
        val repository = MacroRepository(app)
        val macro = repository.save(events, "待删除")
        val file = awaitFile(macro.id)

        repository.delete(macro.id)
        val deadline = System.currentTimeMillis() + 5_000
        while (file.exists() && System.currentTimeMillis() < deadline) Thread.sleep(20)

        assertFalse("file should be gone", file.exists())
        assertFalse(repository.macros.value.any { it.id == macro.id })
    }

    @Test
    fun `renaming updates state and persisted json`() {
        val repository = MacroRepository(app)
        val macro = repository.save(events, "旧名称")
        awaitFile(macro.id)

        repository.rename(macro.id, "新名称")
        val deadline = System.currentTimeMillis() + 5_000
        var persisted = ""
        while (System.currentTimeMillis() < deadline) {
            persisted = runCatching { awaitFile(macro.id).readText() }.getOrDefault("")
            if (persisted.contains("新名称")) break
            Thread.sleep(20)
        }

        assertEquals("新名称", repository.macros.value.first { it.id == macro.id }.name)
        assertTrue("json should contain the new name", persisted.contains("新名称"))
    }

    @Test
    fun `export then import keeps macros intact`() {
        val repository = MacroRepository(app)
        repository.save(events, "导出测试")
        Thread.sleep(200)

        val exported = repository.exportAll()
        val fresh = MacroRepository(app)
        val importedCount = fresh.importText(exported)

        assertTrue(importedCount >= 1)
        assertTrue(fresh.macros.value.any { it.name == "导出测试" })
    }
}
