package com.speedclick.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsNode
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.service.ClickerAccessibilityService
import com.speedclick.app.ui.theme.SpeedClickTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowSettings

/** Verifies that user actions in the UI trigger the expected platform behaviour. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w411dp-h915dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class InteractionTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<ComponentActivity>()

    private fun viewModel(): MainViewModel =
        MainViewModel(ApplicationProvider.getApplicationContext<SpeedClickApp>())

    private fun lastStartedIntent(): Intent? =
        shadowOf(composeRule.activity).nextStartedActivity
            ?: shadowOf(ApplicationProvider.getApplicationContext<SpeedClickApp>()).nextStartedActivity

    @Test
    fun `accessibility card opens accessibility settings`() {
        val vm = viewModel()
        composeRule.setContent { SpeedClickTheme { HomeScreen(vm, onOpenMacros = {}, onOpenPresets = {}) } }
        composeRule.waitForIdle()

        composeRule.onAllNodesWithText("Enable")[0].performClick()
        composeRule.waitForIdle()

        assertEquals(Settings.ACTION_ACCESSIBILITY_SETTINGS, lastStartedIntent()?.action)
    }

    @Test
    fun `floating controls are disabled until the permissions are granted`() {
        val app = ApplicationProvider.getApplicationContext<SpeedClickApp>()
        val vm = viewModel()

        ShadowSettings.setCanDrawOverlays(false)
        vm.refreshPermissions()
        assertFalse("overlay must stay disabled", vm.isOverlayReady())
        assertFalse("playback must stay disabled", vm.isAccessibilityReady())

        ShadowSettings.setCanDrawOverlays(true)
        Settings.Secure.putString(
            app.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            "${app.packageName}/${ClickerAccessibilityService::class.java.name}",
        )
        vm.refreshPermissions()

        assertTrue("overlay should be enabled", vm.isOverlayReady())
        assertTrue("accessibility should be enabled", vm.isAccessibilityReady())
    }

    @Test
    fun `permission checks read the live system state instead of a cached value`() {
        val app = ApplicationProvider.getApplicationContext<SpeedClickApp>()
        val vm = viewModel()
        vm.refreshPermissions()
        assertFalse(vm.isOverlayReady())

        // The user enables the permission in system settings while the app stays open,
        // or the app was just updated: the next check must pick the new state up.
        ShadowSettings.setCanDrawOverlays(true)
        assertTrue("overlay state should be re-read", vm.isOverlayReady())

        Settings.Secure.putString(
            app.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            "${app.packageName}/${ClickerAccessibilityService::class.java.name}",
        )
        assertTrue("accessibility state should be re-read", vm.isAccessibilityReady())
    }

    @Test
    fun `every interactive element meets the 44dp touch target guideline`() {
        val vm = viewModel()
        composeRule.setContent { SpeedClickTheme { HomeScreen(vm, onOpenMacros = {}, onOpenPresets = {}) } }
        composeRule.waitForIdle()

        val density = composeRule.density.density
        val tooSmall = mutableListOf<String>()

        fun walk(node: SemanticsNode) {
            if (node.config.contains(SemanticsActions.OnClick)) {
                val widthDp = node.size.width / density
                val heightDp = node.size.height / density
                val label = node.config.getOrNull(SemanticsProperties.Text)?.joinToString() ?: ""
                if ((widthDp > 0.1f && widthDp < 44f) || (heightDp > 0.1f && heightDp < 44f)) {
                    tooSmall += "$label ${widthDp.toInt()}x${heightDp.toInt()}dp"
                }
            }
            node.children.forEach(::walk)
        }
        walk(composeRule.onRoot(useUnmergedTree = true).fetchSemanticsNode())

        assertTrue("touch targets below 44dp: $tooSmall", tooSmall.isEmpty())
    }

}

