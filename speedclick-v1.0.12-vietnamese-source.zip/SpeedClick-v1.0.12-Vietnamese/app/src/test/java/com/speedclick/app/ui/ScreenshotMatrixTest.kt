package com.speedclick.app.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.data.PresetConfig
import com.speedclick.app.data.PresetRepository
import com.speedclick.app.ui.theme.SpeedClickTheme
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.android.controller.ActivityController
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowDialog
import java.io.File
import java.io.FileOutputStream

/**
 * Renders the screens for several screen profiles so aspect-ratio regressions
 * (clipping, overflow, cramped rows) are visible without a device.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w393dp-h852dp-440dpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ScreenshotMatrixTest {

    private val metrics get() = ApplicationProvider.getApplicationContext<Context>().resources.displayMetrics

    private fun capture(profile: String, name: String, content: @Composable () -> Unit) {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup()
        captureActivity(controller, controller.get(), profile, name, content)
    }

    private fun captureActivity(
        controller: ActivityController<ComponentActivity>,
        activity: ComponentActivity,
        profile: String,
        name: String,
        content: @Composable () -> Unit,
    ) {
        activity.setContent { SpeedClickTheme { content() } }
        shadowOf(Looper.getMainLooper()).idle()

        val bitmap = render(activity.window.decorView, "$profile-$name")
        val dir = File("build/reports/screenshots").apply { mkdirs() }
        FileOutputStream(File(dir, "$profile-$name.png")).use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        controller.pause().stop().destroy()
    }

    /**
     * Compose dialogs live in their own window, so drawing the activity decor view produces a blank
     * image. Capture the dialog window instead, and fail when a render ends up blank - that is how
     * the dialog screenshots silently said nothing for a while.
     */
    private fun captureDialog(profile: String, name: String, content: @Composable () -> Unit) {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup()
        val activity = controller.get()
        activity.setContent { SpeedClickTheme { content() } }
        shadowOf(Looper.getMainLooper()).idle()

        val dialog = requireNotNull(ShadowDialog.getLatestDialog()) { "no dialog was created for $name" }
        val bitmap = render(dialog.window!!.decorView, "$profile-$name")
        val dir = File("build/reports/screenshots").apply { mkdirs() }
        FileOutputStream(File(dir, "$profile-$name.png")).use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        dialog.dismiss()
        controller.pause().stop().destroy()
    }

    /** Fails when a render is (nearly) a single colour, i.e. nothing was actually drawn. */
    private fun render(root: View, label: String): Bitmap {
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        var bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        // Compose sometimes has not laid anything out on the first pass, which used to produce a
        // silently blank screenshot; re-layout and draw again until something is actually there.
        repeat(4) {
            shadowOf(Looper.getMainLooper()).idle()
            root.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY),
            )
            root.layout(0, 0, width, height)
            shadowOf(Looper.getMainLooper()).idle()
            bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            root.draw(Canvas(bitmap))
            if (distinctColours(bitmap) >= 4) return bitmap
        }
        assertNotBlank(bitmap, label)
        return bitmap
    }

    private fun distinctColours(bitmap: Bitmap): Int {
        val seen = HashSet<Int>()
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                seen.add(bitmap.getPixel(x, y))
                if (seen.size >= 4) return seen.size
                x += 8
            }
            y += 8
        }
        return seen.size
    }

    private fun assertNotBlank(bitmap: Bitmap, label: String) {
        val dir = File("build/reports/screenshots").apply { mkdirs() }
        FileOutputStream(File(dir, "$label-BLANK.png")).use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
        throw AssertionError("render '$label' looks blank (distinct colours=${distinctColours(bitmap)})")
    }

    private fun viewModel(): MainViewModel =
        MainViewModel(ApplicationProvider.getApplicationContext<SpeedClickApp>())

    private fun renderAll(profile: String) {
        val vm = viewModel()
        capture(profile, "home") { ContentWidth { HomeScreen(vm, onOpenMacros = {}, onOpenPresets = {}) } }
        capture(profile, "macros") { ContentWidth { MacrosScreen(vm) } }
        capture(profile, "presets") { ContentWidth { PresetsScreen(vm) } }
        capture(profile, "settings") { ContentWidth { SettingsScreen(vm) } }
    }

    @Test
    @Config(qualifiers = "w360dp-h640dp-xhdpi")
    fun smallPhone16x9() = renderAll("p360x640")

    @Test
    @Config(qualifiers = "w393dp-h873dp-440dpi")
    fun modernPhone20x9() = renderAll("p393x873")

    @Test
    @Config(qualifiers = "w412dp-h928dp-xxhdpi")
    fun tallPhone21x9() = renderAll("p412x928")

    @Test
    @Config(qualifiers = "w852dp-h393dp-440dpi")
    fun landscapePhone() = renderAll("l852x393")

    @Test
    @Config(qualifiers = "w600dp-h960dp-xhdpi")
    fun smallTablet4x3() = renderAll("t600x960")

    @Test
    @Config(qualifiers = "w800dp-h1280dp-mdpi")
    fun largeTablet() = renderAll("t800x1280")

    @Test
    @Config(qualifiers = "w852dp-h393dp-440dpi")
    fun landscapeShell() {
        capture("l852x393", "shell") { MainScreen() }
    }

    @Test
    @Config(qualifiers = "w393dp-h873dp-440dpi")
    fun portraitShell() {
        capture("p393x873", "shell") { MainScreen() }
    }

    @Test
    @Config(qualifiers = "w852dp-h393dp-440dpi")
    fun presetDialogLandscape() {
        captureDialog("l852x393", "preset-dialog") {
            PresetDetailDialog(
                config = PresetRepository.defaults.getValue(PresetConfig.PresetType.SWIPE),
                onChange = {},
                onAskPermission = {},
                onPlay = {},
                canPlay = true,
                onDismiss = {},
            )
        }
    }

    @Test
    @Config(qualifiers = "w393dp-h873dp-440dpi")
    fun presetDialogPortrait() {
        captureDialog("p393x873", "preset-dialog") {
            PresetDetailDialog(
                config = PresetRepository.defaults.getValue(PresetConfig.PresetType.SWIPE),
                onChange = {},
                onAskPermission = {},
                onPlay = {},
                canPlay = true,
                onDismiss = {},
            )
        }
    }

    @Test
    @Config(qualifiers = "w393dp-h873dp-night-440dpi")
    fun darkTheme() {
        val vm = viewModel()
        capture("dark-p393x873", "home") { HomeScreen(vm, onOpenMacros = {}, onOpenPresets = {}) }
        capture("dark-p393x873", "settings") { SettingsScreen(vm) }
        capture("dark-p393x873", "presets") { PresetsScreen(vm) }
    }

    /**
     * The English strings are longer than the Chinese ones (e.g. "Display over other apps"), so the
     * portrait and the short landscape profile are rendered in `en` to catch clipped labels.
     */
    @Test
    @Config(qualifiers = "en-rUS-w393dp-h873dp-440dpi")
    fun englishPortrait() = renderAll("en-p393x873")

    @Test
    @Config(qualifiers = "en-rUS-w852dp-h393dp-440dpi")
    fun englishLandscape() = renderAll("en-l852x393")

    @Test
    @Config(qualifiers = "en-rUS-w393dp-h873dp-440dpi")
    fun englishPresetDialog() {
        captureDialog("en-p393x873", "preset-dialog") {
            PresetDetailDialog(
                config = PresetRepository.defaults.getValue(PresetConfig.PresetType.SWIPE),
                onChange = {},
                onAskPermission = {},
                onPlay = {},
                canPlay = true,
                onDismiss = {},
            )
        }
    }

    /** The device screenshots are Chinese; pin `zh-rCN` here so both languages stay covered. */
    @Test
    @Config(qualifiers = "zh-rCN-w393dp-h873dp-440dpi")
    fun chinesePortrait() = renderAll("zh-p393x873")

    @Test
    @Config(qualifiers = "zh-rCN-w852dp-h393dp-440dpi")
    fun chineseLandscape() = renderAll("zh-l852x393")

    @Test
    @Config(qualifiers = "w393dp-h873dp-440dpi")
    fun largeFontScale() {
        val vm = viewModel()
        captureWithFontScale(2.0f, "font2x-p393x873", "home") {
            HomeScreen(vm, onOpenMacros = {}, onOpenPresets = {})
        }
        captureWithFontScale(2.0f, "font2x-p393x873", "settings") { SettingsScreen(vm) }
        captureWithFontScale(1.3f, "font1.3x-p393x873", "home") {
            HomeScreen(vm, onOpenMacros = {}, onOpenPresets = {})
        }
    }

    private fun captureWithFontScale(
        fontScale: Float,
        profile: String,
        name: String,
        content: @Composable () -> Unit,
    ) {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup()
        val activity = controller.get()
        val config = Configuration(activity.resources.configuration)
        config.fontScale = fontScale
        activity.resources.updateConfiguration(config, activity.resources.displayMetrics)
        captureActivity(controller, activity, profile, name, content)
    }
}
