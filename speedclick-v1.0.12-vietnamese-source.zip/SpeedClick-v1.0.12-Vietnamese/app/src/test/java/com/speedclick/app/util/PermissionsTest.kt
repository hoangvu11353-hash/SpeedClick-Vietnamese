package com.speedclick.app.util

import android.provider.Settings
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.service.ClickerAccessibilityService
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSettings

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PermissionsTest {

    private val app: SpeedClickApp get() = ApplicationProvider.getApplicationContext()

    @Test
    fun `accessibility detection matches the enabled services list`() {
        Settings.Secure.putString(app.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, null)
        assertFalse(Permissions.isAccessibilityEnabled(app))

        Settings.Secure.putString(
            app.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            "com.other.app/com.other.Service:${app.packageName}/${ClickerAccessibilityService::class.java.name}",
        )
        assertTrue(Permissions.isAccessibilityEnabled(app))
    }

    @Test
    fun `overlay detection follows the system setting`() {
        ShadowSettings.setCanDrawOverlays(false)
        assertFalse(Permissions.canDrawOverlays(app))

        ShadowSettings.setCanDrawOverlays(true)
        assertTrue(Permissions.canDrawOverlays(app))
    }
}
