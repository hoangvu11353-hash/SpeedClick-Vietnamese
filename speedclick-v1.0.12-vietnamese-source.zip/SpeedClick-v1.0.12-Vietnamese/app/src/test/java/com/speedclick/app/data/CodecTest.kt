package com.speedclick.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class CodecTest {

    private val sample = Macro(
        schemaVersion = 1,
        id = "abc",
        name = "test",
        createdAt = 123L,
        durationMs = 500L,
        events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.5f, 0.5f, 0L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.5f, 0.5f, 40L, 0),
        ),
    )

    @Test
    fun `macro json round trip`() {
        val text = JsonCodec.encode(sample)
        val decoded = JsonCodec.decode<Macro>(text)
        assertEquals(sample, decoded)
    }

    @Test
    fun `macro list json round trip`() {
        val text = JsonCodec.encode(MacroList(macros = listOf(sample)))
        val decoded = JsonCodec.decode<MacroList>(text)
        assertEquals(1, decoded.macros.size)
        assertEquals(sample, decoded.macros.first())
    }

    @Test
    fun `unknown fields are ignored on decode`() {
        val text = """{"id":"x","name":"y","createdAt":1,"durationMs":2,"events":[],"futureField":true}"""
        val decoded = JsonCodec.decode<Macro>(text)
        assertEquals("x", decoded.id)
    }

    @Test
    fun `missing schema version defaults to one`() {
        val text = """{"id":"x","name":"y","createdAt":1,"durationMs":2,"events":[]}"""
        val decoded = JsonCodec.decode<Macro>(text)
        assertEquals(1, decoded.schemaVersion)
    }
}
