package com.speedclick.app.service

import android.content.Intent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Looper
import android.view.View
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.overlay.RecorderController
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream

/**
 * Renders the floating windows (ball, control bar, record panel, target picker) to PNGs so the
 * overlay styling can be reviewed without a device.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w393dp-h873dp-440dpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class OverlayVisualTest {

    private val app: SpeedClickApp get() = ApplicationProvider.getApplicationContext()
    private val metrics get() = app.resources.displayMetrics

    private lateinit var service: OverlayService

    @Before
    fun setUp() {
        RecorderController.cancel()
        RecorderController.clearPending()
        service = Robolectric.buildService(OverlayService::class.java).create().get()
    }

    @After
    fun tearDown() {
        RecorderController.cancel()
        RecorderController.clearPending()
    }

    private fun send(action: String, mode: String? = null) {
        val intent = Intent(app, OverlayService::class.java).setAction(action)
        if (mode != null) intent.putExtra(OverlayService.EXTRA_MODE, mode)
        service.onStartCommand(intent, 0, 1)
        shadowOf(Looper.getMainLooper()).idle()
    }

    private fun field(name: String): Any? =
        OverlayService::class.java.getDeclaredField(name).apply { isAccessible = true }.get(service)

    private fun render(name: String, view: View?, fullScreen: Boolean = false) {
        val target = view ?: error("overlay view '$name' was not created")
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        if (fullScreen) {
            target.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY),
            )
            target.layout(0, 0, width, height)
        } else {
            target.measure(
                View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.AT_MOST),
            )
            target.layout(0, 0, target.measuredWidth, target.measuredHeight)
        }
        val bitmap = Bitmap.createBitmap(
            target.measuredWidth.coerceAtLeast(1),
            target.measuredHeight.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888,
        )
        val canvas = Canvas(bitmap)
        canvas.drawColor(if (fullScreen) Color.parseColor("#2A3245") else Color.parseColor("#111726"))
        target.draw(canvas)

        val dir = File("build/reports/screenshots").apply { mkdirs() }
        FileOutputStream(File(dir, "overlay-$name.png")).use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
    }

    @Test
    fun renderFloatingControls() {
        send(OverlayService.ACTION_CONTROL)
        render("ball", field("ballView") as? View)
        // The bar is expanded by tapping the ball.
        OverlayService::class.java.getDeclaredMethod("toggleControlPanel")
            .apply { isAccessible = true }
            .invoke(service)
        shadowOf(Looper.getMainLooper()).idle()
        render("control-bar", field("controlPanel") as? View)
    }

    @Test
    fun renderRecordPanelStates() {
        send(OverlayService.ACTION_RECORD)
        render("record-ready", field("recordPanel") as? View)

        RecorderController.start(metrics.widthPixels, metrics.heightPixels)
        shadowOf(Looper.getMainLooper()).idle()
        render("record-recording", field("recordPanel") as? View)

        RecorderController.pause()
        shadowOf(Looper.getMainLooper()).idle()
        render("record-paused", field("recordPanel") as? View)
    }

    @Test
    fun renderTargetPicker() {
        send(OverlayService.ACTION_PICKER, "swipe")
        val root = field("pickerRoot") as? View
        render("picker", root, fullScreen = true)
    }
}
