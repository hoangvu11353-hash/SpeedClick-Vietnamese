package com.speedclick.app.service

import android.content.Intent
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.R
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.data.Pt
import com.speedclick.app.data.TouchEvent
import com.speedclick.app.overlay.PickerBus
import com.speedclick.app.overlay.RecorderController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

/**
 * Drives the real overlay views (capture layer and target picker) that the service builds,
 * so the window wiring is verified without a device.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w411dp-h915dp-xxhdpi")
class OverlayWindowTest {

    private val app: SpeedClickApp get() = ApplicationProvider.getApplicationContext()

    private lateinit var service: OverlayService

    private val metrics get() = app.resources.displayMetrics

    @Before
    fun setUp() {
        RecorderController.cancel()
        RecorderController.clearPending()
        service = Robolectric.buildService(OverlayService::class.java).create().get()
    }

    @After
    fun tearDown() {
        RecorderController.cancel()
        RecorderController.clearPending()
    }

    private fun send(action: String, mode: String? = null) {
        val intent = Intent(app, OverlayService::class.java).setAction(action)
        if (mode != null) intent.putExtra(OverlayService.EXTRA_MODE, mode)
        service.onStartCommand(intent, 0, 1)
        shadowOf(Looper.getMainLooper()).idle()
    }

    private fun field(name: String): Any? =
        OverlayService::class.java.getDeclaredField(name).apply { isAccessible = true }.get(service)

    private fun views(root: View?): List<View> {
        if (root == null) return emptyList()
        val result = mutableListOf(root)
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) result += views(root.getChildAt(i))
        }
        return result
    }

    /** The label lives in a TextView inside a clickable pill, so walk up to the clickable node. */
    private fun button(root: View?, label: String): View {
        val text = views(root).filterIsInstance<TextView>().first { it.text.toString() == label }
        var node: View? = text
        while (node != null && !node.isClickable) {
            node = node.parent as? View
        }
        return node ?: text
    }

    @Test
    fun `touches on the capture layer become a normalized macro`() {
        send(OverlayService.ACTION_RECORD)
        assertEquals(RecorderController.Phase.READY, RecorderController.state.value.phase)
        assertNull("capture layer must not exist before recording", field("captureView"))

        RecorderController.start(metrics.widthPixels, metrics.heightPixels)
        shadowOf(Looper.getMainLooper()).idle()

        val capture = field("captureView") as? View
        assertNotNull("capture layer must be added while recording", capture)

        val centerX = metrics.widthPixels / 2f
        val centerY = metrics.heightPixels / 2f
        val t = SystemClock.uptimeMillis()
        capture!!.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, centerX, centerY, 0))
        capture.dispatchTouchEvent(
            MotionEvent.obtain(t, t + 30, MotionEvent.ACTION_MOVE, centerX + 40f, centerY + 20f, 0),
        )
        capture.dispatchTouchEvent(
            MotionEvent.obtain(t, t + 60, MotionEvent.ACTION_UP, centerX + 80f, centerY + 40f, 0),
        )

        RecorderController.stop()
        shadowOf(Looper.getMainLooper()).idle()

        val macro = RecorderController.pendingMacro.value
        assertNotNull(macro)
        assertEquals(
            listOf(TouchEvent.EventType.DOWN, TouchEvent.EventType.MOVE, TouchEvent.EventType.UP),
            macro!!.events.map { it.type },
        )
        assertEquals(0.5f, macro.events.first().x, 0.002f)
        assertEquals(0.5f, macro.events.first().y, 0.002f)
        assertTrue("recorded macro must have a duration", macro.durationMs > 0)
        assertNull("capture layer must be removed after stopping", field("captureView"))
    }

    @Test
    fun `recording keeps using the size that is current for each touch`() {
        send(OverlayService.ACTION_RECORD)
        RecorderController.start(1080, 2400)
        shadowOf(Looper.getMainLooper()).idle()

        val capture = field("captureView") as? View
        assertNotNull("capture layer must be added while recording", capture)

        // The display changes size in the middle of the recording (rotation / resize); the second
        // touch must be normalized against the new size instead of the one captured at start.
        val t = SystemClock.uptimeMillis()
        RecorderController.sizeProvider = { 1080 to 2400 }
        capture!!.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, 1080f, 1200f, 0))
        capture.dispatchTouchEvent(MotionEvent.obtain(t, t + 20, MotionEvent.ACTION_UP, 1080f, 1200f, 0))

        RecorderController.sizeProvider = { 2160 to 2400 }
        capture.dispatchTouchEvent(MotionEvent.obtain(t, t + 40, MotionEvent.ACTION_DOWN, 1080f, 1200f, 0))
        capture.dispatchTouchEvent(MotionEvent.obtain(t, t + 60, MotionEvent.ACTION_UP, 1080f, 1200f, 0))
        RecorderController.sizeProvider = null

        RecorderController.stop()
        shadowOf(Looper.getMainLooper()).idle()
        val macro = RecorderController.pendingMacro.value
        assertNotNull(macro)
        val downs = macro!!.events.filter { it.type == TouchEvent.EventType.DOWN }
        assertEquals(2, downs.size)
        assertEquals("first touch is relative to the start size", 1.0f, downs[0].x, 0.0001f)
        assertEquals("second touch is relative to the new size", 0.5f, downs[1].x, 0.0001f)
    }

    @Test
    fun `confirming a single point picker returns the marker centre`() = runBlocking {
        val received = mutableListOf<List<Pt>?>()
        val scope = CoroutineScope(Dispatchers.Default)
        val collector = scope.launch { PickerBus.results.collect { received += it } }
        try {
            send(OverlayService.ACTION_PICKER, "point")
            val root = field("pickerRoot") as? View
            assertNotNull("picker window must be created", root)

            val marker = field("pickerMarker") as View
            val size = (field("markerSizePx") as Int).toFloat()

            button(root, app.getString(R.string.confirm)).performClick()
            withTimeout(3_000) { while (received.isEmpty()) delay(20) }

            val points = received.first()
            assertNotNull(points)
            assertEquals(1, points!!.size)

            // The stored point is the crosshair position in screen coordinates. The overlay
            // window can be inset by the system (ColorOS on Android 17 starts it below the status
            // bar), which is why the picker reads the marker's location on screen instead of
            // adding up layout offsets - those used to be off by the status bar height.
            val loc = IntArray(2)
            marker.getLocationOnScreen(loc)
            assertEquals((loc[0] + size / 2f) / metrics.widthPixels, points[0].x, 0.002f)
            assertEquals((loc[1] + size / 2f) / metrics.heightPixels, points[0].y, 0.002f)
            // Untouched, the crosshair sits in the middle of the screen.
            assertEquals(0.5f, points[0].x, 0.01f)
            assertEquals(0.5f, points[0].y, 0.01f)
        } finally {
            collector.cancel()
        }
    }

    @Test
    fun `swipe picker needs two locked points before it can be confirmed`() = runBlocking {
        val received = mutableListOf<List<Pt>?>()
        val scope = CoroutineScope(Dispatchers.Default)
        val collector = scope.launch { PickerBus.results.collect { received += it } }
        try {
            send(OverlayService.ACTION_PICKER, "swipe")
            val root = field("pickerRoot") as View
            val marker = field("pickerMarker") as View

            // Confirming too early must be rejected.
            button(root, app.getString(R.string.confirm)).performClick()
            delay(200)
            assertTrue("confirm must be rejected without two points", received.isEmpty())

            val lock = button(root, app.getString(R.string.picker_lock_point))
            marker.translationY = -200f
            lock.performClick()
            marker.translationY = 200f
            lock.performClick()

            button(root, app.getString(R.string.confirm)).performClick()
            withTimeout(3_000) { while (received.isEmpty()) delay(20) }

            val points = received.first()
            assertNotNull(points)
            assertEquals(2, points!!.size)
            assertTrue("start point must be above the end point", points[0].y < points[1].y)
        } finally {
            collector.cancel()
        }
    }
}
