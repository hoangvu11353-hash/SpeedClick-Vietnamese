package com.speedclick.app.engine

import com.speedclick.app.data.TouchEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class GestureChunkerTest {

    private val limits = GestureChunker.Limits(maxGestureDurationMs = 60_000L, maxStrokeCount = 10)

    private fun tap(t: Long, x: Float = 0.5f, y: Float = 0.5f, pointer: Int = 0) = listOf(
        TouchEvent(TouchEvent.EventType.DOWN, x, y, t, pointer),
        TouchEvent(TouchEvent.EventType.UP, x, y, t + 40, pointer),
    )

    @Test
    fun `many taps pack into chunks of max stroke count`() {
        val events = (0 until 25).flatMap { i -> tap(i * 100L) }
        val chunks = GestureChunker.buildChunks(events, 1080f, 2400f, 1f, limits)
        assertEquals(3, chunks.size)
        assertEquals(listOf(10, 10, 5), chunks.map { it.strokes.size })
    }

    @Test
    fun `simultaneous multi touch stays in one chunk`() {
        val events = tap(0L, x = 0.3f, pointer = 0) + tap(0L, x = 0.7f, pointer = 1)
        val chunks = GestureChunker.buildChunks(events, 1080f, 2400f, 1f, limits)
        assertEquals(1, chunks.size)
        assertEquals(2, chunks[0].strokes.size)
    }

    @Test
    fun `long press longer than max duration splits across windows`() {
        val events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.5f, 0.5f, 0L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.5f, 0.5f, 200_000L, 0),
        )
        val chunks = GestureChunker.buildChunks(events, 1080f, 2400f, 1f, limits)
        assertEquals(4, chunks.size)
        val total = chunks.sumOf { chunk -> chunk.strokes.sumOf { it.endMs - it.startMs } }
        assertEquals(200_000L, total)
    }

    @Test
    fun `speed scales event timestamps`() {
        val events = tap(1_000L)
        val chunks = GestureChunker.buildChunks(events, 1080f, 2400f, speed = 2f, limits = limits)
        assertEquals(500L, chunks.first().startMs)
    }

    @Test
    fun `normalized coordinates map to absolute pixels`() {
        val events = tap(0L, x = 0.5f, y = 0.25f)
        val chunks = GestureChunker.buildChunks(events, 1080f, 2400f, 1f, limits)
        val point = chunks.first().strokes.first().points.first()
        assertEquals(540f, point.x, 0.001f)
        assertEquals(600f, point.y, 0.001f)
    }

    @Test
    fun `jitter stays within configured radius`() {
        val events = tap(0L)
        val chunks = GestureChunker.buildChunks(
            events, 1080f, 2400f, 1f, limits,
            jitterPx = 5f,
            random = Random(42),
        )
        val point = chunks.first().strokes.first().points.first()
        assertTrue(kotlin.math.abs(point.x - 540f) <= 5f)
        assertTrue(kotlin.math.abs(point.y - 1200f) <= 5f)
    }

    @Test
    fun `compress merges tiny close move events`() {
        val events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.5f, 0.5f, 0L, 0),
            TouchEvent(TouchEvent.EventType.MOVE, 0.501f, 0.501f, 10L, 0),
            TouchEvent(TouchEvent.EventType.MOVE, 0.502f, 0.502f, 12L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.5f, 0.5f, 40L, 0),
        )
        val compressed = GestureChunker.compress(events)
        assertEquals(3, compressed.size)
    }

    @Test
    fun `swipe crossing a chunk window is split without losing path or duration`() {
        val events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.2f, 0.5f, 59_950L, 0),
            TouchEvent(TouchEvent.EventType.MOVE, 0.5f, 0.5f, 60_000L, 0),
            TouchEvent(TouchEvent.EventType.MOVE, 0.8f, 0.5f, 60_050L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.8f, 0.5f, 60_050L, 0),
        )
        val chunks = GestureChunker.buildChunks(events, 1080f, 2400f, 1f, limits)
        assertEquals(2, chunks.size)
        assertEquals(59_950L, chunks[0].startMs)
        assertEquals(60_000L, chunks[1].startMs)

        val total = chunks.sumOf { chunk -> chunk.strokes.sumOf { it.endMs - it.startMs } }
        assertEquals(100L, total)

        val first = chunks[0].strokes.first().points.first()
        assertEquals(216f, first.x, 0.5f)
        val last = chunks[1].strokes.first().points.last()
        assertEquals(864f, last.x, 0.5f)
    }

    @Test
    fun `both pointers of a long multi touch press are split`() {
        val events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.3f, 0.5f, 0L, 0),
            TouchEvent(TouchEvent.EventType.DOWN, 0.7f, 0.5f, 0L, 1),
            TouchEvent(TouchEvent.EventType.UP, 0.3f, 0.5f, 90_000L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.7f, 0.5f, 90_000L, 1),
        )
        val chunks = GestureChunker.buildChunks(events, 1080f, 2400f, 1f, limits)
        assertEquals(2, chunks.size)
        assertEquals(listOf(2, 2), chunks.map { it.strokes.size })
        val total = chunks.sumOf { chunk -> chunk.strokes.sumOf { it.endMs - it.startMs } }
        assertEquals(180_000L, total)
    }
}
