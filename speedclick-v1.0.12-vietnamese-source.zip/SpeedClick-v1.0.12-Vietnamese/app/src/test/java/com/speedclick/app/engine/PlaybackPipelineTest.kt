package com.speedclick.app.engine

import android.accessibilityservice.GestureDescription
import android.graphics.RectF
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.data.PlaybackSpec
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.data.TouchEvent
import com.speedclick.app.service.ClickerAccessibilityService
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowSystemClock
import java.time.Duration

/**
 * End-to-end playback: the engine chunking, the accessibility dispatch call and the
 * iteration loop are exercised together on the JVM.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PlaybackPipelineTest {

    private val service: ClickerAccessibilityService = Robolectric
        .buildService(ClickerAccessibilityService::class.java)
        .create()
        .get()

    private val tap = PlaybackSpec(
        label = "tap",
        events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.5f, 0.5f, 0L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.5f, 0.5f, 40L, 0),
        ),
        delayMs = 0,
        repeat = 2,
        intervalMs = 0,
        speed = 1f,
        jitterPx = 0f,
    )

    private fun dispatches() = shadowOf(service).gesturesDispatched

    /** Completes dispatched gestures so the engine can move on, then waits for a condition. */
    private fun pump(handled: Int, timeoutMs: Long = 8_000, until: () -> Boolean): Int {
        var index = handled
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            // Robolectric freezes SystemClock.uptimeMillis(), so drive it forward: the engine
            // schedules each chunk against that clock.
            ShadowSystemClock.advanceBy(Duration.ofMillis(25))
            val all = dispatches()
            while (index < all.size) {
                val dispatch = all[index]
                dispatch.callback().onCompleted(dispatch.description())
                index++
            }
            if (until() && index >= dispatches().size) return index
            Thread.sleep(20)
        }
        return index
    }

    @Before
    fun setUp() {
        shadowOf(service).setCanDispatchGestures(true)
        ClickerAccessibilityService.instance = service
        PlaybackEngine.stop()
    }

    @After
    fun tearDown() {
        PlaybackEngine.stop()
        ClickerAccessibilityService.instance = null
    }

    @Test
    fun `repeating macro dispatches one gesture per iteration and returns to idle`() {
        PlaybackEngine.start(tap)
        assertEquals(PlaybackStatus.RUNNING, PlaybackEngine.state.value.status)

        val handled = pump(handled = 0) { PlaybackEngine.state.value.status == PlaybackStatus.IDLE }
        assertEquals("state=${PlaybackEngine.state.value} handled=$handled", 2, handled)
        // Finishing a session clears it, so the idle state carries no label or progress.
        assertEquals(PlaybackStatus.IDLE, PlaybackEngine.state.value.status)
        assertEquals(0, PlaybackEngine.state.value.iteration)
        assertEquals("", PlaybackEngine.state.value.label)
    }

    @Test
    fun `gesture coordinates follow the normalized macro position`() {
        PlaybackEngine.start(tap.copy(repeat = 1))
        pump(handled = 0) { PlaybackEngine.state.value.status == PlaybackStatus.IDLE }

        val gesture = dispatches().first().description()
        assertEquals(1, gesture.strokeCount)
        val bounds = RectF()
        gesture.getStroke(0).path.computeBounds(bounds, true)

        val metrics = ApplicationProvider.getApplicationContext<SpeedClickApp>().resources.displayMetrics
        assertEquals(metrics.widthPixels / 2f, bounds.centerX(), 1f)
        assertEquals(metrics.heightPixels / 2f, bounds.centerY(), 1f)
    }

    @Test
    fun `paused playback stops dispatching until it is resumed`() {
        PlaybackEngine.start(tap.copy(repeat = 0))

        var handled = pump(handled = 0) { dispatches().isNotEmpty() }
        assertTrue("first iteration must be dispatched", handled >= 1)

        PlaybackEngine.pause()
        handled = pump(handled) { PlaybackEngine.state.value.status == PlaybackStatus.PAUSED }
        val whilePaused = dispatches().size

        Thread.sleep(400)
        assertEquals("no new gesture may be dispatched while paused", whilePaused, dispatches().size)

        PlaybackEngine.resume()
        handled = pump(handled) { dispatches().size > whilePaused }
        assertTrue("resuming must continue the loop", dispatches().size > whilePaused)

        PlaybackEngine.stop()
        assertEquals(PlaybackStatus.IDLE, PlaybackEngine.state.value.status)
    }

    /**
     * Regression: the loop used to schedule every iteration against an absolute clock, so the
     * time spent paused became a backlog that was replayed at maximum speed on resume (a 20 s
     * pause resumed at roughly 2.2x the configured rate for another 20 s).
     */
    @Test
    fun `resuming after a long pause keeps the cadence instead of replaying missed iterations`() {
        PlaybackEngine.start(tap.copy(repeat = 0, intervalMs = 1_000))

        var handled = pump(handled = 0) { dispatches().isNotEmpty() }
        assertTrue("first iteration must be dispatched", handled >= 1)

        PlaybackEngine.pause()
        handled = pump(handled) { PlaybackEngine.state.value.status == PlaybackStatus.PAUSED }
        val whilePaused = dispatches().size

        // The user stays paused for five seconds while the wall clock keeps running.
        ShadowSystemClock.advanceBy(Duration.ofMillis(5_000))
        assertEquals("nothing may be dispatched while paused", whilePaused, dispatches().size)

        PlaybackEngine.resume()
        // ~2.5 s of virtual time at 1 s per iteration: only the next two iterations are due,
        // while a backlog would fire the five missed ones on top of that.
        pump(handled, timeoutMs = 2_000) { false }
        val afterResume = dispatches().size - whilePaused
        assertTrue("resume replayed the pause backlog ($afterResume iterations)", afterResume <= 4)

        PlaybackEngine.stop()
    }

    /** Regression: a frozen process (doze, app standby) must not turn into a burst of clicks. */
    @Test
    fun `a long stall does not turn into a burst of catch-up iterations`() {
        PlaybackEngine.start(tap.copy(repeat = 0, intervalMs = 1_000))

        var handled = pump(handled = 0) { dispatches().isNotEmpty() }
        val beforeStall = dispatches().size

        ShadowSystemClock.advanceBy(Duration.ofMillis(5_000))
        handled = pump(handled, timeoutMs = 1_500) { false }
        val afterStall = dispatches().size - beforeStall
        assertTrue("stall replayed the backlog ($afterStall iterations)", afterStall <= 3)

        PlaybackEngine.stop()
    }

    /**
     * Regression (observed on Android 17 / ColorOS): the accessibility layer sometimes never
     * delivers the gesture callback, which used to leave the session "running" without ever
     * dispatching again. The engine must notice the lost callback and end the session.
     */
    @Test
    fun `a lost gesture callback ends the session instead of hanging forever`() {
        PlaybackEngine.start(tap.copy(repeat = 0))

        // Nothing completes the dispatched gestures here, so only the engine's own timeout can
        // move things along.
        val deadline = System.currentTimeMillis() + 30_000
        while (System.currentTimeMillis() < deadline &&
            PlaybackEngine.state.value.status == PlaybackStatus.RUNNING
        ) {
            ShadowSystemClock.advanceBy(Duration.ofMillis(100))
            Thread.sleep(20)
        }

        assertEquals(
            "lost callbacks must end the session",
            PlaybackStatus.ERROR,
            PlaybackEngine.state.value.status,
        )
        assertTrue("the gesture must have been retried", dispatches().size >= 2)
    }

    /**
     * The accessibility service rejects gestures while any touch is in progress (a finger resting
     * on the screen does it), so dispatch rejections are normal and deserve a growing backoff
     * instead of ending the session after half a second.
     */
    @Test
    fun `rejected dispatches are retried with backoff before the session fails`() {
        shadowOf(service).setCanDispatchGestures(false)
        val startedAt = System.currentTimeMillis()
        PlaybackEngine.start(tap.copy(repeat = 0))

        val deadline = startedAt + 20_000
        while (System.currentTimeMillis() < deadline &&
            PlaybackEngine.state.value.status == PlaybackStatus.RUNNING
        ) {
            ShadowSystemClock.advanceBy(Duration.ofMillis(50))
            Thread.sleep(20)
        }
        val elapsed = System.currentTimeMillis() - startedAt

        assertEquals(PlaybackStatus.ERROR, PlaybackEngine.state.value.status)
        // Rejections are retried with growing backoff (150+300+600+1200 ms), so giving up after
        // the very first rejection - the old behaviour - would finish in a few milliseconds.
        assertTrue("rejections must be retried with backoff (elapsed=${elapsed}ms)", elapsed >= 1_500)
    }
}
