package com.speedclick.app.engine

import com.speedclick.app.data.Pt
import com.speedclick.app.data.PresetConfig
import com.speedclick.app.data.TouchEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PresetEngineTest {

    @Test
    fun `every preset produces a valid event sequence`() {
        val configs = listOf(
            PresetConfig(PresetConfig.PresetType.SINGLE_TAP, points = listOf(Pt(0.5f, 0.5f))),
            PresetConfig(PresetConfig.PresetType.MULTI_TAP, points = listOf(Pt(0.3f, 0.5f), Pt(0.7f, 0.5f))),
            PresetConfig(PresetConfig.PresetType.DOUBLE_TAP, points = listOf(Pt(0.5f, 0.5f))),
            PresetConfig(PresetConfig.PresetType.LONG_PRESS, points = listOf(Pt(0.5f, 0.5f)), holdMs = 500),
            PresetConfig(PresetConfig.PresetType.SWIPE, points = listOf(Pt(0.5f, 0.2f), Pt(0.5f, 0.8f))),
        )
        configs.forEach { config ->
            val events = PresetEngine.buildIteration(config)
            assertTrue("events empty for ${config.type}", events.isNotEmpty())
            assertEquals(TouchEvent.EventType.DOWN, events.first().type)
            assertEquals(TouchEvent.EventType.UP, events.last().type)
            events.forEach {
                assertTrue(it.x in 0f..1f)
                assertTrue(it.y in 0f..1f)
                assertTrue(it.t >= 0)
            }
            assertTrue(PresetEngine.iterationDuration(config) > 0)
        }
    }

    @Test
    fun `multi tap uses one pointer per point`() {
        val config = PresetConfig(
            PresetConfig.PresetType.MULTI_TAP,
            points = listOf(Pt(0.2f, 0.5f), Pt(0.5f, 0.5f), Pt(0.8f, 0.5f)),
        )
        val events = PresetEngine.buildIteration(config)
        assertEquals(setOf(0, 1, 2), events.map { it.pointer }.toSet())
    }

    @Test
    fun `swipe moves from start to end point`() {
        val config = PresetConfig(
            PresetConfig.PresetType.SWIPE,
            points = listOf(Pt(0.5f, 0.2f), Pt(0.5f, 0.8f)),
            swipeMs = 500,
        )
        val events = PresetEngine.buildIteration(config)
        assertEquals(Pt(0.5f, 0.2f), Pt(events.first().x, events.first().y))
        assertEquals(Pt(0.5f, 0.8f), Pt(events.last().x, events.last().y))
    }
}
