package com.speedclick.app.engine

import com.speedclick.app.data.PlaybackSpec
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.data.TouchEvent
import com.speedclick.app.service.ClickerAccessibilityService
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import org.robolectric.Robolectric
import org.robolectric.Shadows.shadowOf
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PlaybackEngineTest {

    private val spec = PlaybackSpec(
        label = "test",
        events = listOf(
            TouchEvent(TouchEvent.EventType.DOWN, 0.5f, 0.5f, 0L, 0),
            TouchEvent(TouchEvent.EventType.UP, 0.5f, 0.5f, 40L, 0),
        ),
        delayMs = 0,
        repeat = 1,
        intervalMs = 0,
        speed = 1f,
        jitterPx = 0f,
    )

    @After
    fun tearDown() {
        PlaybackEngine.stop()
    }

    @Test
    fun `a permanently failing gesture retries and then reports an error`() = runBlocking {
        val service = Robolectric.buildService(ClickerAccessibilityService::class.java).create().get()
        // Every dispatch reports failure, like a gesture that keeps being cancelled.
        shadowOf(service).setCanDispatchGestures(false)
        ClickerAccessibilityService.instance = service
        try {
            val startedAt = System.currentTimeMillis()
            PlaybackEngine.start(spec)
            withTimeout(10_000) {
                while (PlaybackEngine.state.value.status == PlaybackStatus.RUNNING) delay(20)
            }
            val elapsed = System.currentTimeMillis() - startedAt
            val state = PlaybackEngine.state.value
            assertEquals("expected a dispatch failure, got $state", PlaybackStatus.ERROR, state.status)
            assertTrue("expected retries before giving up, took ${elapsed}ms", elapsed >= 250)
        } finally {
            ClickerAccessibilityService.instance = null
        }
    }

    @Test
    fun `starting without the accessibility service surfaces an error instead of crashing`() = runBlocking {
        PlaybackEngine.start(spec)
        assertEquals(PlaybackStatus.RUNNING, PlaybackEngine.state.value.status)

        withTimeout(10_000) {
            while (PlaybackEngine.state.value.status == PlaybackStatus.RUNNING) delay(50)
        }

        val state = PlaybackEngine.state.value
        assertEquals(PlaybackStatus.ERROR, state.status)
        assertNotNull(state.error)
    }

    @Test
    fun `stop resets the engine to idle`() = runBlocking {
        PlaybackEngine.start(spec)
        PlaybackEngine.stop()
        assertEquals(PlaybackStatus.IDLE, PlaybackEngine.state.value.status)
    }

    @Test
    fun `pause and resume only apply to a running session`() {
        PlaybackEngine.stop()
        PlaybackEngine.pause()
        assertEquals(PlaybackStatus.IDLE, PlaybackEngine.state.value.status)

        PlaybackEngine.resume()
        assertEquals(PlaybackStatus.IDLE, PlaybackEngine.state.value.status)
    }
}

