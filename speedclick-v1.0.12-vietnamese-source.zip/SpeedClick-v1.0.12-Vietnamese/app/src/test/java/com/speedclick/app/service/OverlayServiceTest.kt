package com.speedclick.app.service

import android.app.NotificationManager
import android.content.Intent
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.engine.PlaybackEngine
import com.speedclick.app.overlay.RecorderController
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class OverlayServiceTest {

    private val app: SpeedClickApp get() = ApplicationProvider.getApplicationContext()

    @After
    fun tearDown() {
        RecorderController.cancel()
        RecorderController.clearPending()
        PlaybackEngine.stop()
    }

    private fun startService(action: String, mode: String? = null): OverlayService {
        val controller = Robolectric.buildService(OverlayService::class.java).create()
        val service = controller.get()
        val intent = Intent(app, OverlayService::class.java).setAction(action)
        if (mode != null) intent.putExtra(OverlayService.EXTRA_MODE, mode)
        service.onStartCommand(intent, 0, 1)
        shadowOf(Looper.getMainLooper()).idle()
        return service
    }

    private fun postedNotifications() =
        shadowOf(app.getSystemService(NotificationManager::class.java)).allNotifications

    @Test
    fun `record action starts a foreground service and prepares the recorder`() {
        val service = startService(OverlayService.ACTION_RECORD)

        assertTrue("a service notification must be posted", postedNotifications().isNotEmpty())
        assertEquals(RecorderController.Phase.READY, RecorderController.state.value.phase)
        assertTrue(shadowOf(service).isStoppedBySelf.not())
    }

    @Test
    fun `cancelling the recording session stops the service`() {
        val service = startService(OverlayService.ACTION_RECORD)
        RecorderController.cancel()
        shadowOf(Looper.getMainLooper()).idle()

        assertTrue("service should stop itself once nothing is shown", shadowOf(service).isStoppedBySelf)
    }

    @Test
    fun `picker action loads without crashing and keeps the service alive`() {
        val service = startService(OverlayService.ACTION_PICKER, mode = "multi")
        // The picker stays open until it is confirmed or cancelled.
        assertTrue(shadowOf(service).isStoppedBySelf.not())
        assertEquals(RecorderController.Phase.IDLE, RecorderController.state.value.phase)
    }

    @Test
    fun `notification stop action ends recording and playback`() {
        startService(OverlayService.ACTION_RECORD)
        RecorderController.start(1080, 2400)
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals(RecorderController.Phase.RECORDING, RecorderController.state.value.phase)

        ControlReceiver().onReceive(app, Intent(ControlReceiver.ACTION_STOP))
        shadowOf(Looper.getMainLooper()).idle()

        assertEquals(RecorderController.Phase.IDLE, RecorderController.state.value.phase)
        assertEquals(PlaybackStatus.IDLE, PlaybackEngine.state.value.status)
    }
}
