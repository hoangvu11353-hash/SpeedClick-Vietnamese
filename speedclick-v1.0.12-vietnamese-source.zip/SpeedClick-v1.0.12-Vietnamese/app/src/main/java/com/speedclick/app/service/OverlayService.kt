package com.speedclick.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.RippleDrawable
import android.util.Log
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import com.speedclick.app.R
import com.speedclick.app.data.Pt
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.engine.PlaybackEngine
import com.speedclick.app.overlay.PickerBus
import com.speedclick.app.overlay.RecorderController
import com.speedclick.app.overlay.OverlayViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

class OverlayService : Service() {

    enum class PickerMode(val minPoints: Int, val maxPoints: Int) {
        POINT(1, 1),
        MULTI(2, 4),
        SWIPE(2, 2);

        companion object {
            fun parse(value: String?): PickerMode = when (value) {
                "multi" -> MULTI
                "swipe" -> SWIPE
                else -> POINT
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private var commandHandled = false

    private var recordPanel: LinearLayout? = null
    private var recordPanelParams: WindowManager.LayoutParams? = null
    private var recordStatusChip: View? = null
    private var recordBtn: ImageButton? = null
    private var pauseBtn: ImageButton? = null
    private var stopBtn: ImageButton? = null
    private var captureView: View? = null

    private var ballView: ImageButton? = null
    private var ballParams: WindowManager.LayoutParams? = null
    private var controlPanel: LinearLayout? = null
    private var controlToggle: ImageButton? = null
    private var controlStatusChip: View? = null

    private var pickerRoot: FrameLayout? = null
    private var pickerMarker: View? = null
    private var pickerPanel: View? = null
    private var pickerCount: TextView? = null
    private var pickerLockBtn: View? = null
    private var pickerMode = PickerMode.POINT
    private var lastNotifiedIteration = -1
    private val pickerPoints = mutableListOf<Pt>()
    private var markerSizePx = 0
    private var screenW = 0f
    private var screenH = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        // A service instance always outlives its recording session; drop stale state.
        if (RecorderController.state.value.phase != RecorderController.Phase.IDLE) {
            RecorderController.cancel()
        }
        createChannel()
        // Recording samples must be normalized against the size that is current at that moment.
        RecorderController.sizeProvider = { currentDisplaySize() }
        observePlayback()
        observeRecorder()
        observePendingMacro()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        commandHandled = true
        when (intent?.action) {
            ACTION_RECORD -> showRecordPanel()
            ACTION_CONTROL -> showControlBall()
            ACTION_PICKER -> showPicker(PickerMode.parse(intent.getStringExtra(EXTRA_MODE)))
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        RecorderController.sizeProvider = null
        removeAllWindows()
        super.onDestroy()
    }

    // ---------------- foreground & notification ----------------

    private fun goForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_SERVICE,
            getString(R.string.notif_channel_service),
            NotificationManager.IMPORTANCE_LOW,
        ).apply { setShowBadge(false) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val rec = RecorderController.state.value.phase
        val pb = PlaybackEngine.state.value
        val hasPendingMacro = RecorderController.pendingMacro.value != null

        val text: CharSequence
        val actions = mutableListOf<NotificationCompat.Action>()
        when {
            rec == RecorderController.Phase.RECORDING || rec == RecorderController.Phase.PAUSED -> {
                text = getString(R.string.notif_recording_active)
                actions += broadcastAction(1, getString(R.string.stop), ControlReceiver.ACTION_STOP)
            }
            rec == RecorderController.Phase.READY -> {
                text = getString(R.string.notif_recording_ready)
                actions += broadcastAction(1, getString(R.string.cancel), ControlReceiver.ACTION_STOP)
            }
            pb.status == PlaybackStatus.RUNNING -> {
                text = getString(R.string.notif_playback_running, "${pb.label} · ${pb.iteration}")
                actions += broadcastAction(1, getString(R.string.pause), ControlReceiver.ACTION_PAUSE)
                actions += broadcastAction(2, getString(R.string.stop), ControlReceiver.ACTION_STOP)
            }
            pb.status == PlaybackStatus.PAUSED -> {
                text = getString(R.string.notif_playback_paused, "${pb.label} · ${pb.iteration}")
                actions += broadcastAction(1, getString(R.string.resume), ControlReceiver.ACTION_RESUME)
                actions += broadcastAction(2, getString(R.string.stop), ControlReceiver.ACTION_STOP)
            }
            hasPendingMacro -> {
                text = getString(R.string.notif_macro_ready)
                actions += NotificationCompat.Action(
                    0,
                    getString(R.string.save),
                    openAppPendingIntent(3),
                )
            }
            else -> text = getString(R.string.state_idle)
        }

        return NotificationCompat.Builder(this, CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppPendingIntent(0))
            .apply { actions.forEach { addAction(it) } }
            .build()
    }

    private fun openAppPendingIntent(requestCode: Int): PendingIntent = PendingIntent.getActivity(
        this,
        requestCode,
        Intent(this, com.speedclick.app.MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun broadcastAction(requestCode: Int, label: String, action: String): NotificationCompat.Action {
        val pi = PendingIntent.getBroadcast(
            this,
            requestCode,
            Intent(this, ControlReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Action(0, label, pi)
    }

    @SuppressLint("MissingPermission")
    private fun updateNotification() {
        val manager = NotificationManagerCompat.from(this)
        if (!manager.areNotificationsEnabled()) return
        runCatching { manager.notify(NOTIF_ID, buildNotification()) }
    }

    // ---------------- playback control ----------------

    private fun observePlayback() {
        scope.launch {
            PlaybackEngine.state.collect { st ->
                when (st.status) {
                    PlaybackStatus.RUNNING -> {
                        showControlBall()
                        refreshControlPanel()
                        // Update the notification at most every 10 iterations: frequent posts
                        // would waste CPU during fast loops.
                        if (st.iteration - lastNotifiedIteration >= 10 || st.iteration < lastNotifiedIteration) {
                            lastNotifiedIteration = st.iteration
                            updateNotification()
                        }
                    }
                    PlaybackStatus.PAUSED -> {
                        refreshControlPanel()
                        updateNotification()
                    }
                    else -> {
                        hideControl()
                        updateNotification()
                        maybeStopSelf()
                    }
                }
            }
        }
    }

    private fun showControlBall() {
        if (ballView != null) return
        val ball = ImageButton(this).apply {
            setImageResource(R.drawable.ic_ov_bolt)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER
            contentDescription = getString(R.string.fg_ball_desc)
            background = RippleDrawable(
                ColorStateList.valueOf(Color.argb(70, 255, 255, 255)),
                OverlayViews.circle(this@OverlayService, COLOR_BRAND.toColorInt()),
                null,
            )
            elevation = dp(8).toFloat()
            isClickable = true
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val params = WindowManager.LayoutParams(
            dp(52),
            dp(52),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(140)
        }
        attachDragAndClick(ball, params) { toggleControlPanel() }
        ballView = ball
        ballParams = params
        runCatching { wm.addView(ball, params) }.onFailure { ballView = null }
    }

    private fun toggleControlPanel() {
        if (controlPanel != null) hideControlPanel() else showControlPanel()
    }

    private fun showControlPanel() {
        if (controlPanel != null) return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = OverlayViews.rounded(this@OverlayService, OverlayViews.PANEL, 26)
            elevation = dp(10).toFloat()
        }
        val toggle = OverlayViews.iconButton(
            this,
            R.drawable.ic_ov_pause,
            OverlayViews.BRAND,
            contentDescription = getString(R.string.pause),
        ) {
            if (PlaybackEngine.state.value.status == PlaybackStatus.PAUSED) {
                PlaybackEngine.resume()
            } else {
                PlaybackEngine.pause()
            }
        }
        val stop = OverlayViews.iconButton(
            this,
            R.drawable.ic_ov_stop,
            OverlayViews.DANGER,
            contentDescription = getString(R.string.stop),
        ) { PlaybackEngine.stop() }
        val hide = OverlayViews.iconButton(
            this,
            R.drawable.ic_ov_close,
            OverlayViews.NEUTRAL,
            contentDescription = getString(R.string.cancel),
        ) { hideControlPanel() }
        controlStatusChip = OverlayViews.statusChip(
            this,
            getString(R.string.state_running),
            OverlayViews.SUCCESS,
        )
        panel.addView(controlStatusChip)
        panel.addView(toggle)
        panel.addView(stop)
        panel.addView(hide)
        controlToggle = toggle
        controlPanel = panel
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(200)
        }
        runCatching { wm.addView(panel, params) }.onFailure { controlPanel = null }
        refreshControlPanel()
    }

    private fun hideControlPanel() {
        controlPanel?.let { runCatching { wm.removeView(it) } }
        controlPanel = null
        controlToggle = null
    }

    private fun hideControl() {
        hideControlPanel()
        ballView?.let { runCatching { wm.removeView(it) } }
        ballView = null
        ballParams = null
    }

    private fun refreshControlPanel() {
        val paused = PlaybackEngine.state.value.status == PlaybackStatus.PAUSED
        controlToggle?.setImageResource(if (paused) R.drawable.ic_ov_play else R.drawable.ic_ov_pause)
        OverlayViews.updateStatusChip(
            controlStatusChip,
            getString(if (paused) R.string.state_paused else R.string.state_running),
            if (paused) OverlayViews.BRAND else OverlayViews.SUCCESS,
        )
    }

    // ---------------- recording ----------------

    private fun observeRecorder() {
        scope.launch {
            RecorderController.state.collect { st ->
                when (st.phase) {
                    RecorderController.Phase.RECORDING -> {
                        addCaptureView()
                        refreshRecordPanel()
                        updateNotification()
                    }
                    RecorderController.Phase.PAUSED -> {
                        refreshRecordPanel()
                        updateNotification()
                    }
                    RecorderController.Phase.READY -> {
                        refreshRecordPanel()
                        updateNotification()
                    }
                    RecorderController.Phase.IDLE -> {
                        removeCaptureView()
                        removeRecordPanel()
                        updateNotification()
                        maybeStopSelf()
                    }
                }
            }
        }
    }

    private fun observePendingMacro() {
        scope.launch {
            RecorderController.pendingMacro.collect {
                updateNotification()
                maybeStopSelf()
            }
        }
    }

    private fun showRecordPanel() {
        if (recordPanel == null) {
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(7), dp(7), dp(7), dp(7))
                background = OverlayViews.rounded(this@OverlayService, OverlayViews.PANEL, 26)
                elevation = dp(10).toFloat()
            }
            recordPanel = panel
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(32)
                y = dp(180)
            }
            recordPanelParams = params

            panel.addView(
                OverlayViews.dragHandle(this) { dx, dy -> moveWindow(recordPanelParams, recordPanel, dx, dy) },
            )
            recordStatusChip = OverlayViews.statusChip(
                this,
                getString(R.string.record_status_ready),
                OverlayViews.MUTED,
            )
            panel.addView(recordStatusChip)
            recordBtn = OverlayViews.iconButton(
                this,
                R.drawable.ic_ov_record,
                OverlayViews.BRAND,
                contentDescription = getString(R.string.action_record),
            ) { onRecordButton() }
            pauseBtn = OverlayViews.iconButton(
                this,
                R.drawable.ic_ov_pause,
                OverlayViews.DISABLED,
                contentDescription = getString(R.string.pause),
            ) { onPauseButton() }
            stopBtn = OverlayViews.iconButton(
                this,
                R.drawable.ic_ov_stop,
                OverlayViews.DISABLED,
                contentDescription = getString(R.string.stop),
            ) { RecorderController.stop() }
            panel.addView(recordBtn)
            panel.addView(pauseBtn)
            panel.addView(stopBtn)
            panel.addView(
                OverlayViews.iconButton(
                    this,
                    R.drawable.ic_ov_close,
                    OverlayViews.NEUTRAL,
                    contentDescription = getString(R.string.cancel),
                ) { RecorderController.cancel() },
            )
            runCatching { wm.addView(panel, params) }.onFailure { recordPanel = null }
        }
        RecorderController.ready()
        refreshRecordPanel()
        updateNotification()
    }

    private fun onRecordButton() {
        if (RecorderController.state.value.phase != RecorderController.Phase.READY) return
        val size = currentDisplaySize()
        RecorderController.start(size.first, size.second)
    }

    /** Current display size in the active orientation (bounds update with rotation/resize). */
    private fun currentDisplaySize(): Pair<Int, Int> {
        val bounds = wm.currentWindowMetrics.bounds
        if (bounds.width() > 0 && bounds.height() > 0) return bounds.width() to bounds.height()
        val point = Point()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealSize(point)
        return point.x to point.y
    }

    private fun onPauseButton() {
        when (RecorderController.state.value.phase) {
            RecorderController.Phase.RECORDING -> RecorderController.pause()
            RecorderController.Phase.PAUSED -> RecorderController.resume()
            else -> Unit
        }
    }

    private fun refreshRecordPanel() {
        val phase = RecorderController.state.value.phase
        val active = phase == RecorderController.Phase.RECORDING || phase == RecorderController.Phase.PAUSED
        val paused = phase == RecorderController.Phase.PAUSED

        recordBtn?.isEnabled = !active
        OverlayViews.setButtonBackground(
            recordBtn,
            if (active) OverlayViews.DISABLED else OverlayViews.BRAND,
        )

        val statusText = when (phase) {
            RecorderController.Phase.READY -> getString(R.string.record_status_ready)
            RecorderController.Phase.RECORDING -> getString(R.string.record_status_recording)
            RecorderController.Phase.PAUSED -> getString(R.string.record_status_paused)
            else -> ""
        }
        val dotColor = when (phase) {
            RecorderController.Phase.RECORDING -> OverlayViews.DANGER
            RecorderController.Phase.PAUSED -> OverlayViews.BRAND
            else -> OverlayViews.MUTED
        }
        OverlayViews.updateStatusChip(recordStatusChip, statusText, dotColor)

        pauseBtn?.isEnabled = active
        pauseBtn?.setImageResource(if (paused) R.drawable.ic_ov_play else R.drawable.ic_ov_pause)
        OverlayViews.setButtonBackground(
            pauseBtn,
            if (active) OverlayViews.BRAND else OverlayViews.DISABLED,
        )

        stopBtn?.isEnabled = active
        OverlayViews.setButtonBackground(
            stopBtn,
            if (active) OverlayViews.DANGER else OverlayViews.DISABLED,
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addCaptureView() {
        if (captureView != null) return
        val view = object : View(this) {
            override fun onTouchEvent(event: MotionEvent): Boolean {
                RecorderController.onTouch(event)
                return true
            }
        }.apply {
            isClickable = true
            setBackgroundColor(Color.TRANSPARENT)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        captureView = view
        // Re-add the panel after the capture view so the panel stays on top.
        val panel = recordPanel
        val panelParams = recordPanelParams
        if (panel != null && panelParams != null) runCatching { wm.removeView(panel) }
        runCatching { wm.addView(view, params) }.onFailure { captureView = null }
        if (panel != null && panelParams != null) runCatching { wm.addView(panel, panelParams) }
    }

    private fun removeCaptureView() {
        captureView?.let { runCatching { wm.removeView(it) } }
        captureView = null
    }

    private fun removeRecordPanel() {
        recordPanel?.let { runCatching { wm.removeView(it) } }
        recordPanel = null
        recordPanelParams = null
        recordStatusChip = null
        recordBtn = null
        pauseBtn = null
        stopBtn = null
    }

    // ---------------- target picker ----------------

    private fun showPicker(mode: PickerMode) {
        pickerRoot?.let { runCatching { wm.removeView(it) } }
        pickerRoot = null
        pickerMarker = null
        pickerPanel = null
        pickerMode = mode
        pickerPoints.clear()

        val size = currentDisplaySize()
        screenW = size.first.toFloat()
        screenH = size.second.toFloat()

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(18, 0, 0, 0))
            isClickable = true
            setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_UP) performClick()
                true
            }
        }
        val rootParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )

        val markerSize = dp(64)
        markerSizePx = markerSize
        val marker = View(this).apply {
            background = OverlayViews.crosshair(this@OverlayService)
            isClickable = true
        }
        val markerLp = FrameLayout.LayoutParams(markerSize, markerSize, Gravity.TOP or Gravity.START).apply {
            leftMargin = 0
            topMargin = 0
        }
        var lastX = 0f
        var lastY = 0f
        marker.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = ev.rawX
                    lastY = ev.rawY
                    // On short screens the button panel can sit over the crosshair; fade it so the
                    // user always sees the marker while dragging.
                    pickerPanel?.alpha = 0.3f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    v.translationX += ev.rawX - lastX
                    v.translationY += ev.rawY - lastY
                    lastX = ev.rawX
                    lastY = ev.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.performClick()
                    pickerPanel?.alpha = 1f
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    pickerPanel?.alpha = 1f
                    true
                }
                else -> true
            }
        }
        root.addView(marker, markerLp)
        pickerMarker = marker

        val hint = OverlayViews.hintChip(this, R.drawable.ic_ov_target, getString(R.string.picker_hint))
        root.addView(hint, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL,
        ).apply { topMargin = dp(80) })

        // Short screens (landscape phones ~360dp tall, split screen) would otherwise have the panel
        // covering the crosshair that sits at the screen centre.
        val density = resources.displayMetrics.density
        val compact = screenH / density < 480f
        val panelPad = if (compact) dp(6) else dp(10)
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(panelPad, panelPad, panelPad, panelPad)
            background = OverlayViews.rounded(this@OverlayService, OverlayViews.PANEL, 24)
            elevation = dp(10).toFloat()
        }
        val count = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = if (compact) 11f else 13f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, if (compact) dp(4) else dp(8))
        }
        val lock = OverlayViews.labelButton(
            this,
            R.drawable.ic_ov_target,
            getString(R.string.picker_lock_point),
            OverlayViews.BRAND,
        ) {
            pickerPoints.add(currentCenter())
            refreshPickerUi()
        }
        val reset = OverlayViews.labelButton(
            this,
            R.drawable.ic_ov_refresh,
            getString(R.string.picker_reset),
            OverlayViews.NEUTRAL,
        ) {
            pickerPoints.clear()
            refreshPickerUi()
        }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(lock, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(4)
        })
        row1.addView(reset, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(4)
        })
        val confirm = OverlayViews.labelButton(
            this,
            R.drawable.ic_ov_check,
            getString(R.string.confirm),
            OverlayViews.SUCCESS,
        ) { confirmPicker() }
        val cancel = OverlayViews.labelButton(
            this,
            R.drawable.ic_ov_close,
            getString(R.string.cancel),
            OverlayViews.NEUTRAL,
        ) { cancelPicker() }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, if (compact) dp(4) else dp(8), 0, 0)
        }
        row2.addView(confirm, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(4)
        })
        row2.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(4)
        })
        bottom.addView(count)
        bottom.addView(row1)
        bottom.addView(row2)
        if (compact) {
            listOf(lock, reset, confirm, cancel).forEach { it.minimumHeight = dp(34) }
        }
        root.addView(bottom, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
        ).apply {
            bottomMargin = if (compact) dp(14) else dp(48)
            width = dp(300)
        })

        pickerCount = count
        pickerLockBtn = lock
        pickerPanel = bottom
        pickerRoot = root
        runCatching { wm.addView(root, rootParams) }.onFailure { pickerRoot = null }
        root.post {
            // The overlay window is not guaranteed to start at the screen origin (ColorOS on
            // Android 17 insets it below the status bar), so place the crosshair by removing the
            // window offset. Otherwise the marker is drawn lower than the point that gets stored.
            val loc = IntArray(2)
            root.getLocationOnScreen(loc)
            marker.translationX = screenW / 2f - markerSize / 2f - loc[0]
            marker.translationY = screenH / 2f - markerSize / 2f - loc[1]
        }
        refreshPickerUi()
    }

    private fun currentCenter(): Pt {
        val marker = pickerMarker ?: return Pt(0.5f, 0.5f)
        // Re-read the size: the display can change while the picker is open (rotation/resize) and
        // the stored point must be normalized against the size that is current right now.
        val live = currentDisplaySize()
        if (live.first > 0 && live.second > 0) {
            screenW = live.first.toFloat()
            screenH = live.second.toFloat()
        }
        // Screen coordinates (window offset included) so the stored point matches the crosshair.
        val loc = IntArray(2)
        marker.getLocationOnScreen(loc)
        val size = if (markerSizePx > 0) markerSizePx else marker.width
        val cx = loc[0] + size / 2f
        val cy = loc[1] + size / 2f
        return Pt((cx / screenW).coerceIn(0f, 1f), (cy / screenH).coerceIn(0f, 1f))
    }

    private fun refreshPickerUi() {
        val need = pickerMode.minPoints - pickerPoints.size
        val base = resources.getQuantityString(R.plurals.points_count, pickerPoints.size, pickerPoints.size)
        pickerCount?.text = if (need > 0) {
            "$base · " + resources.getQuantityString(R.plurals.picker_need_points, need, need)
        } else {
            base
        }
        pickerLockBtn?.isEnabled = pickerPoints.size < pickerMode.maxPoints
        val lockEnabled = pickerPoints.size < pickerMode.maxPoints
        OverlayViews.setButtonBackground(
            pickerLockBtn,
            if (lockEnabled) OverlayViews.BRAND else OverlayViews.DISABLED,
        )
        pickerLockBtn?.alpha = if (lockEnabled) 1f else 0.7f
    }

    private fun confirmPicker() {
        val points = if (pickerPoints.isEmpty() && pickerMode == PickerMode.POINT) {
            listOf(currentCenter())
        } else {
            pickerPoints.toList()
        }
        if (points.size < pickerMode.minPoints || points.size > pickerMode.maxPoints) {
            val need = pickerMode.minPoints - points.size
            val message = resources.getQuantityString(
                R.plurals.picker_need_points,
                need.coerceAtLeast(0),
                need.coerceAtLeast(0),
            )
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            return
        }
        finishPicker(points)
    }

    private fun cancelPicker() {
        finishPicker(null)
    }

    private fun finishPicker(points: List<Pt>?) {
        points?.forEachIndexed { index, p ->
            val size = currentDisplaySize()
            Log.d(
                TAG,
                "picker point[$index] nx=${p.x} ny=${p.y} " +
                    "px=${(p.x * size.first).toInt()} py=${(p.y * size.second).toInt()} " +
                    "screen=${size.first}x${size.second}",
            )
        }
        pickerRoot?.let { runCatching { wm.removeView(it) } }
        pickerRoot = null
        pickerMarker = null
        pickerPanel = null
        pickerCount = null
        pickerLockBtn = null
        PickerBus.submit(points)
        maybeStopSelf()
    }

    // ---------------- helpers ----------------

    private fun maybeStopSelf() {
        // State collectors run as soon as the service is created; never tear down before
        // the start command has had the chance to build its windows.
        if (!commandHandled) return
        val pb = PlaybackEngine.state.value.status
        val rec = RecorderController.state.value.phase
        if ((pb == PlaybackStatus.IDLE || pb == PlaybackStatus.ERROR) &&
            rec == RecorderController.Phase.IDLE &&
            RecorderController.pendingMacro.value == null &&
            pickerRoot == null
        ) {
            stopSelf()
        }
    }

    private fun removeAllWindows() {
        listOfNotNull(captureView, recordPanel, ballView, controlPanel, pickerRoot).forEach {
            runCatching { wm.removeView(it) }
        }
        captureView = null
        recordPanel = null
        ballView = null
        controlPanel = null
        pickerRoot = null
        pickerMarker = null
        pickerPanel = null
    }

    private fun moveWindow(params: WindowManager.LayoutParams?, view: View?, dx: Int, dy: Int) {
        val p = params ?: return
        val v = view ?: return
        p.x += dx
        p.y += dy
        runCatching { wm.updateViewLayout(v, p) }
    }

    private fun attachDragAndClick(view: View, params: WindowManager.LayoutParams, onClick: () -> Unit) {
        var lastX = 0f
        var lastY = 0f
        var moved = false
        view.setOnTouchListener { ball, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = ev.rawX
                    lastY = ev.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - lastX).toInt()
                    val dy = (ev.rawY - lastY).toInt()
                    if (abs(dx) > 3 || abs(dy) > 3) moved = true
                    if (dx != 0 || dy != 0) moveWindow(params, view, dx, dy)
                    lastX = ev.rawX
                    lastY = ev.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        ball.performClick()
                        onClick()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val TAG = "SpeedClick"
        const val ACTION_RECORD = "com.speedclick.app.overlay.RECORD"
        const val ACTION_CONTROL = "com.speedclick.app.overlay.CONTROL"
        const val ACTION_PICKER = "com.speedclick.app.overlay.PICKER"
        const val EXTRA_MODE = "picker_mode"
        private const val NOTIF_ID = 42
        private const val CHANNEL_SERVICE = "service"
        private const val COLOR_BRAND = "#2F6BFF"

        fun start(context: Context, action: String, mode: String? = null) {
            val intent = Intent(context, OverlayService::class.java).setAction(action)
            if (mode != null) intent.putExtra(EXTRA_MODE, mode)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
