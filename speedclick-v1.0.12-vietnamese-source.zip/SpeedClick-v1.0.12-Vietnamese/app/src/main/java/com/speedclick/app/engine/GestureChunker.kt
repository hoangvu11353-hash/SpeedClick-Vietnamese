package com.speedclick.app.engine

import com.speedclick.app.data.TouchEvent
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

data class StrokePoint(val x: Float, val y: Float)

data class Stroke(
    val startMs: Long,
    val endMs: Long,
    val points: List<StrokePoint>,
    val pointer: Int,
)

data class Chunk(val startMs: Long, val strokes: List<Stroke>)

object GestureChunker {

    const val MIN_STROKE_MS = 10L

    data class Limits(val maxGestureDurationMs: Long, val maxStrokeCount: Int)

    fun compress(events: List<TouchEvent>): List<TouchEvent> {
        val byPointer = LinkedHashMap<Int, MutableList<TouchEvent>>()
        events.forEach { byPointer.getOrPut(it.pointer) { mutableListOf() }.add(it) }
        val out = mutableListOf<TouchEvent>()
        byPointer.forEach { (_, evs) ->
            var last: TouchEvent? = null
            evs.forEach { e ->
                val prev = last
                if (prev != null &&
                    e.type == TouchEvent.EventType.MOVE &&
                    prev.type == TouchEvent.EventType.MOVE &&
                    abs(e.x - prev.x) < 0.003f &&
                    abs(e.y - prev.y) < 0.003f &&
                    (e.t - prev.t) < 5
                ) {
                    last = e
                    return@forEach
                }
                out.add(e)
                last = e
            }
        }
        return out.sortedBy { it.t }
    }

    fun buildChunks(
        events: List<TouchEvent>,
        width: Float,
        height: Float,
        speed: Float,
        limits: Limits,
        jitterPx: Float = 0f,
        random: Random = Random.Default,
    ): List<Chunk> {
        require(width > 0 && height > 0) { "invalid screen size" }
        val maxDur = limits.maxGestureDurationMs.coerceAtLeast(1000L)
        val maxCount = limits.maxStrokeCount.coerceAtLeast(1)
        val effectiveSpeed = speed.coerceIn(0.5f, 5f)

        val strokes = toStrokes(compress(events), width, height, effectiveSpeed).map { stroke ->
            if (jitterPx <= 0f) stroke
            else stroke.copy(
                points = stroke.points.map { p ->
                    StrokePoint(
                        p.x + (random.nextFloat() * 2f - 1f) * jitterPx,
                        p.y + (random.nextFloat() * 2f - 1f) * jitterPx,
                    )
                },
            )
        }

        val segmentsByWindow = sortedMapOf<Long, MutableList<Stroke>>()
        strokes.forEach { stroke ->
            var t = stroke.startMs
            while (t < stroke.endMs) {
                val window = t / maxDur
                val windowEnd = (window + 1) * maxDur
                val segEnd = min(stroke.endMs, windowEnd)
                segmentsByWindow.getOrPut(window) { mutableListOf() }.add(clipStroke(stroke, t, segEnd))
                t = segEnd
            }
        }

        val chunks = mutableListOf<Chunk>()
        segmentsByWindow.forEach { (_, segments) ->
            segments.sortBy { it.startMs }
            var idx = 0
            while (idx < segments.size) {
                val group = segments.subList(idx, min(idx + maxCount, segments.size)).toList()
                val chunkStart = group.minOf { it.startMs }
                val relative = group.map { s -> s.copy(startMs = s.startMs - chunkStart, endMs = s.endMs - chunkStart) }
                chunks.add(Chunk(startMs = chunkStart, strokes = relative))
                idx += maxCount
            }
        }
        return chunks.sortedBy { it.startMs }
    }

    private fun toStrokes(events: List<TouchEvent>, width: Float, height: Float, speed: Float): List<Stroke> {
        val byPointer = LinkedHashMap<Int, MutableList<TouchEvent>>()
        events.sortedBy { it.t }.forEach { byPointer.getOrPut(it.pointer) { mutableListOf() }.add(it) }

        val strokes = mutableListOf<Stroke>()
        byPointer.forEach { (pointer, evs) ->
            var down: TouchEvent? = null
            val points = mutableListOf<StrokePoint>()
            evs.forEach { e ->
                when (e.type) {
                    TouchEvent.EventType.DOWN -> {
                        down = e
                        points.clear()
                        points.add(toPx(e, width, height))
                    }
                    TouchEvent.EventType.MOVE -> if (down != null) points.add(toPx(e, width, height))
                    TouchEvent.EventType.UP -> {
                        val d = down
                        if (d != null) {
                            points.add(toPx(e, width, height))
                            val start = scale(d.t, speed)
                            val end = maxOf(scale(e.t, speed), start + MIN_STROKE_MS)
                            strokes.add(Stroke(start, end, dedupe(points), pointer))
                        }
                        down = null
                        points.clear()
                    }
                }
            }
            val d = down
            if (d != null) {
                val start = scale(d.t, speed)
                val end = maxOf(scale(evs.last().t, speed), start + MIN_STROKE_MS)
                strokes.add(Stroke(start, end, dedupe(points), pointer))
            }
        }
        return strokes.sortedBy { it.startMs }
    }

    private fun clipStroke(stroke: Stroke, from: Long, to: Long): Stroke {
        val n = stroke.points.size
        if (n <= 1) return Stroke(from, to, stroke.points, stroke.pointer)
        val dur = (stroke.endMs - stroke.startMs).coerceAtLeast(1L)
        val startFrac = ((from - stroke.startMs).toFloat() / dur).coerceIn(0f, 1f)
        val endFrac = ((to - stroke.startMs).toFloat() / dur).coerceIn(0f, 1f)
        val startPos = positionAt(stroke.points, startFrac)
        val endPos = positionAt(stroke.points, endFrac)
        val inner = stroke.points.filterIndexed { idx, _ ->
            val f = idx.toFloat() / (n - 1)
            f >= startFrac && f <= endFrac
        }
        val pts = mutableListOf(startPos)
        inner.forEach { if (it != pts.last()) pts.add(it) }
        if (endPos != pts.last()) pts.add(endPos)
        return Stroke(from, to, pts, stroke.pointer)
    }

    private fun positionAt(points: List<StrokePoint>, frac: Float): StrokePoint {
        val n = points.size
        if (n <= 1) return points.first()
        val pos = frac * (n - 1)
        val i = pos.toInt().coerceIn(0, n - 2)
        val f = pos - i
        val a = points[i]
        val b = points[i + 1]
        return StrokePoint(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
    }

    private fun dedupe(points: List<StrokePoint>): List<StrokePoint> {
        val out = mutableListOf<StrokePoint>()
        points.forEach { p -> if (out.isEmpty() || out.last() != p) out.add(p) }
        return out
    }

    private fun toPx(e: TouchEvent, width: Float, height: Float): StrokePoint =
        StrokePoint(e.x.coerceIn(0f, 1f) * width, e.y.coerceIn(0f, 1f) * height)

    private fun scale(t: Long, speed: Float): Long = (t / speed).toLong()
}
