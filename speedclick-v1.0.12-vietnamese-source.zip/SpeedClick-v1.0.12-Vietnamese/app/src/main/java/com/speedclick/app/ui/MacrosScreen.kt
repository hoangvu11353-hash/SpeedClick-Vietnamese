package com.speedclick.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speedclick.app.R
import com.speedclick.app.data.Macro
import com.speedclick.app.service.OverlayService
import com.speedclick.app.util.Permissions
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun MacrosScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val macros by vm.macros.collectAsStateWithLifecycle()
    val macrosLoaded by vm.macrosLoaded.collectAsStateWithLifecycle()
    val overlayGranted by vm.overlayGranted.collectAsStateWithLifecycle()
    val jitter by vm.jitterPx.collectAsStateWithLifecycle(initialValue = 0f)
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val msgExportSuccess = stringResource(R.string.export_success)
    val msgExportFailed = stringResource(R.string.export_failed)
    val msgNeedOverlay = stringResource(R.string.need_overlay_permission)
    val msgPlaybackFailed = stringResource(R.string.playback_failed)
    val msgGrant = stringResource(R.string.grant)

    var renameTarget by remember { mutableStateOf<Macro?>(null) }
    var renameName by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Macro?>(null) }
    var playTarget by remember { mutableStateOf<Macro?>(null) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var exportTarget by remember { mutableStateOf<Macro?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        val target = exportTarget
        if (uri != null && target != null) {
            scope.launch {
                val json = vm.exportMacro(target.id)
                val ok = runCatching {
                    context.contentResolver.openOutputStream(uri)?.use {
                        it.write((json ?: "").toByteArray(Charsets.UTF_8))
                    } != null
                }.getOrDefault(false)
                snackbarHostState.showSnackbar(
                    if (ok) msgExportSuccess else msgExportFailed,
                )
            }
        }
    }

    fun startRecording() {
        if (vm.isOverlayReady()) {
            OverlayService.start(context, OverlayService.ACTION_RECORD)
            return
        }
        scope.launch {
            val result = snackbarHostState.showSnackbar(
                message = msgNeedOverlay,
                actionLabel = msgGrant,
                duration = SnackbarDuration.Short,
            )
            if (result == SnackbarResult.ActionPerformed) Permissions.openOverlaySettings(context)
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { startRecording() },
                icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                text = { Text(stringResource(R.string.action_record)) },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
        ) {
            ScreenHeader(
                title = stringResource(R.string.macros_title),
                subtitle = when {
                    !macrosLoaded || macros.isEmpty() -> null
                    else -> pluralStringResource(R.plurals.macros_count, macros.size, macros.size)
                },
            )
            if (macros.isEmpty() && !macrosLoaded) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                    CircularProgressIndicator(modifier = Modifier.padding(top = 64.dp))
                }
            } else if (macros.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 32.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        IconBadge(
                            icon = Icons.Outlined.TouchApp,
                            tint = MaterialTheme.colorScheme.primary,
                            container = MaterialTheme.colorScheme.primaryContainer,
                            size = 64,
                        )
                        Text(
                            text = stringResource(R.string.macros_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 96.dp),
                ) {
                    items(macros, key = { it.id }) { macro ->
                        MacroCard(
                            macro = macro,
                            menuExpanded = menuFor == macro.id,
                            onToggleMenu = { menuFor = if (menuFor == macro.id) null else macro.id },
                            onPlay = { playTarget = macro },
                            onRename = {
                                menuFor = null
                                renameName = macro.name
                                renameTarget = macro
                            },
                            onExport = {
                                menuFor = null
                                exportTarget = macro
                                exportLauncher.launch("${macro.name}.json")
                            },
                            onDelete = {
                                menuFor = null
                                deleteTarget = macro
                            },
                        )
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        NameInputDialog(
            title = stringResource(R.string.rename_title),
            initial = renameName,
            onConfirm = { name ->
                vm.renameMacro(target.id, name)
                renameTarget = null
            },
            onDismiss = { renameTarget = null },
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text(stringResource(R.string.delete_confirm_title)) },
            text = { Text(stringResource(R.string.delete_confirm_msg, target.name)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteMacro(target.id)
                    deleteTarget = null
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }

    playTarget?.let { target ->
        PlayDialog(
            onConfirm = { repeat, interval, speed ->
                playTarget = null
                if (!vm.isAccessibilityReady()) {
                    scope.launch {
                        val result = snackbarHostState.showSnackbar(
                            message = msgPlaybackFailed,
                            actionLabel = msgGrant,
                            duration = SnackbarDuration.Short,
                        )
                        if (result == SnackbarResult.ActionPerformed) {
                            Permissions.openAccessibilitySettings(context)
                        }
                    }
                } else {
                    vm.playMacro(target, repeat, interval, speed, jitter)
                }
            },
            onDismiss = { playTarget = null },
        )
    }
}

@Composable
private fun MacroCard(
    macro: Macro,
    menuExpanded: Boolean,
    onToggleMenu: () -> Unit,
    onPlay: () -> Unit,
    onRename: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit,
) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(
                icon = Icons.Outlined.TouchApp,
                tint = MaterialTheme.colorScheme.primary,
                container = MaterialTheme.colorScheme.primaryContainer,
                size = 40,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = macro.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = formatDuration(macro.durationMs) +
                        " · " + pluralStringResource(R.plurals.macro_event_count, macro.events.size, macro.events.size),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FilledTonalIconButton(onClick = onPlay) {
                Icon(
                    Icons.Outlined.PlayArrow,
                    contentDescription = stringResource(R.string.action_play),
                    modifier = Modifier.size(20.dp),
                )
            }
            Box {
                IconButton(onClick = onToggleMenu) {
                    Icon(Icons.Outlined.MoreVert, contentDescription = null)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = onToggleMenu) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.rename_title)) },
                        leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                        onClick = onRename,
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_export)) },
                        leadingIcon = { Icon(Icons.Outlined.FileUpload, contentDescription = null) },
                        onClick = onExport,
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.delete)) },
                        leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null) },
                        onClick = onDelete,
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayDialog(
    onConfirm: (Int, Long, Float) -> Unit,
    onDismiss: () -> Unit,
) {
    var repeat by remember { mutableStateOf("0") }
    var interval by remember { mutableStateOf("0") }
    var speed by remember { mutableFloatStateOf(1f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.play_options_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = repeat,
                    onValueChange = { repeat = it },
                    label = { Text(stringResource(R.string.param_repeat)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = interval,
                    onValueChange = { interval = it },
                    label = { Text(stringResource(R.string.param_interval)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    text = stringResource(
                        R.string.param_speed_value,
                        String.format(Locale.US, "%.1f", speed),
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                )
                Slider(
                    value = speed,
                    onValueChange = { speed = it },
                    valueRange = 0.5f..5f,
                    steps = 8,
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val r = repeat.toIntOrNull() ?: 0
                val i = (interval.toLongOrNull() ?: 0L).coerceIn(0L, 60_000L)
                onConfirm(r, i, speed)
            }) { Text(stringResource(R.string.play)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}
