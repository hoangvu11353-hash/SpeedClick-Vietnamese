package com.speedclick.app.overlay

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Styling for the floating windows. Keeps the established look (dark translucent pills,
 * brand blue accents) but uses crisp vector icons instead of text glyphs.
 */
object OverlayViews {
    val PANEL = Color.argb(242, 20, 27, 51)
    val PANEL_SOFT = Color.argb(235, 30, 39, 66)
    val BRAND = Color.parseColor("#2F6BFF")
    val DANGER = Color.parseColor("#E5484D")
    val NEUTRAL = Color.parseColor("#5A6478")
    val SUCCESS = Color.parseColor("#2FA45C")
    val MUTED = Color.parseColor("#8A93A6")
    val DISABLED = Color.argb(58, 255, 255, 255)

    fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    fun rounded(context: Context, color: Int, radiusDp: Int = 23): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(context, radiusDp).toFloat()
            setColor(color)
        }

    fun circle(context: Context, color: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }

    /** Square icon button with a rounded background and a touch ripple. */
    fun iconButton(
        context: Context,
        iconRes: Int,
        background: Int,
        sizeDp: Int = 46,
        contentDescription: String? = null,
        onClick: () -> Unit,
    ): ImageButton {
        val size = dp(context, sizeDp)
        val button = ImageButton(context).apply {
            setImageResource(iconRes)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER
            this.contentDescription = contentDescription
            this.background = RippleDrawable(
                ColorStateList.valueOf(Color.argb(60, 255, 255, 255)),
                rounded(context, background, 15),
                null,
            )
            setPadding(dp(context, 10), dp(context, 10), dp(context, 10), dp(context, 10))
        }
        button.layoutParams = LinearLayout.LayoutParams(size, size).apply {
            marginStart = dp(context, 3)
            marginEnd = dp(context, 3)
        }
        button.setOnClickListener { onClick() }
        return button
    }

    /** Pill button with an icon and a label, used inside the picker panel. */
    fun labelButton(
        context: Context,
        iconRes: Int,
        label: String,
        background: Int,
        onClick: () -> Unit,
    ): LinearLayout {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            this.background = RippleDrawable(
                ColorStateList.valueOf(Color.argb(60, 255, 255, 255)),
                rounded(context, background, 15),
                null,
            )
            isClickable = true
            setPadding(dp(context, 10), dp(context, 10), dp(context, 10), dp(context, 10))
            minimumHeight = dp(context, 46)
        }
        row.addView(ImageView(context).apply {
            setImageResource(iconRes)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(context, 18), dp(context, 18))
        })
        row.addView(TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(dp(context, 6), 0, 0, 0)
        })
        row.setOnClickListener { onClick() }
        return row
    }

    /** Small chip showing a coloured dot plus a status label. */
    fun statusChip(context: Context, label: String, dotColor: Int): LinearLayout {
        val chip = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(context, PANEL_SOFT, 14)
            setPadding(dp(context, 10), dp(context, 7), dp(context, 12), dp(context, 7))
        }
        chip.addView(View(context).apply {
            background = circle(context, dotColor)
            layoutParams = LinearLayout.LayoutParams(dp(context, 8), dp(context, 8))
        })
        chip.addView(TextView(context).apply {
            id = STATUS_TEXT_ID
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(context, 8), 0, 0, 0)
        })
        return chip
    }

    fun updateStatusChip(chip: View?, text: String, dotColor: Int) {
        val label = chip?.findViewById<TextView>(STATUS_TEXT_ID) ?: return
        label.text = text
        val dot = (chip as? LinearLayout)?.getChildAt(0)
        if (dot != null) dot.background = circle(dot.context, dotColor)
    }

    /** Re-applies the rounded background of an icon button (state changes re-tint it). */
    fun setButtonBackground(button: View?, color: Int) {
        val context = button?.context ?: return
        button.background = RippleDrawable(
            ColorStateList.valueOf(Color.argb(60, 255, 255, 255)),
            rounded(context, color, 15),
            null,
        )
        button.alpha = if (button.isEnabled) 1f else 0.55f
    }

    /** Six-dot handle used to drag floating panels around. */
    fun dragHandle(context: Context, onMove: (Int, Int) -> Unit): View {
        val handle = ImageView(context).apply {
            setImageResource(com.speedclick.app.R.drawable.ic_ov_drag)
            imageTintList = ColorStateList.valueOf(MUTED)
            layoutParams = LinearLayout.LayoutParams(dp(context, 34), dp(context, 46))
            setPadding(dp(context, 5), dp(context, 11), dp(context, 5), dp(context, 11))
            isClickable = true
        }
        var lastX = 0f
        var lastY = 0f
        handle.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - lastX).toInt()
                    val dy = (event.rawY - lastY).toInt()
                    if (dx != 0 || dy != 0) onMove(dx, dy)
                    lastX = event.rawX
                    lastY = event.rawY
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.performClick()
                    true
                }
                else -> true
            }
        }
        return handle
    }

    /** Hint chip with an icon, shown above the target marker. */
    fun hintChip(context: Context, iconRes: Int, text: String): LinearLayout {
        val chip = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(context, Color.argb(215, 20, 27, 51), 18)
            setPadding(dp(context, 12), dp(context, 8), dp(context, 14), dp(context, 8))
        }
        chip.addView(ImageView(context).apply {
            setImageResource(iconRes)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(context, 16), dp(context, 16))
        })
        chip.addView(TextView(context).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(context, 8), 0, 0, 0)
        })
        return chip
    }

    /** Crosshair target: white outer ring, brand inner ring, red centre dot. */
    fun crosshair(context: Context): LayerDrawable {
        val outer = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(context, 2), Color.WHITE)
        }
        val inner = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setStroke(dp(context, 2), BRAND)
        }
        val dot = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#FF4D4F"))
        }
        val layers = LayerDrawable(arrayOf(outer, inner, dot))
        layers.setLayerInset(0, 0, 0, 0, 0)
        layers.setLayerInset(1, dp(context, 9), dp(context, 9), dp(context, 9), dp(context, 9))
        layers.setLayerInset(2, dp(context, 28), dp(context, 28), dp(context, 28), dp(context, 28))
        return layers
    }

    private const val STATUS_TEXT_ID = 0x7f0f0001
}
