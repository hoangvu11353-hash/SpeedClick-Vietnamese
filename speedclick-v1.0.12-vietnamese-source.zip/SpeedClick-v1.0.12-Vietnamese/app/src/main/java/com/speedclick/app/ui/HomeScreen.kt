package com.speedclick.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Accessibility
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.BatteryFull
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speedclick.app.R
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.ui.theme.SuccessGreen
import com.speedclick.app.util.Permissions

@Composable
fun HomeScreen(vm: MainViewModel, onOpenMacros: () -> Unit, onOpenPresets: () -> Unit) {
    val context = LocalContext.current
    val acc by vm.accessibilityGranted.collectAsStateWithLifecycle()
    val overlay by vm.overlayGranted.collectAsStateWithLifecycle()
    val notif by vm.notificationsGranted.collectAsStateWithLifecycle()
    val battery by vm.batteryIgnored.collectAsStateWithLifecycle()
    val playback by vm.playback.collectAsStateWithLifecycle()

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshPermissions()
    }
    val required = listOf(acc, overlay, notif)
    val done = required.count { it }
    val allGranted = done == required.size

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        ScreenHeader(
            title = stringResource(R.string.home_title),
            subtitle = stringResource(
                if (allGranted) R.string.home_ready_desc else R.string.home_setup_hint,
            ),
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            LinearProgressIndicator(
                progress = { done.toFloat() / required.size },
                modifier = Modifier.weight(1f).height(8.dp),
            )
            Spacer(Modifier.width(12.dp))
            if (allGranted) {
                StatusPill(
                    text = stringResource(R.string.home_ready_title),
                    container = SuccessGreen.copy(alpha = 0.14f),
                    contentColor = SuccessGreen,
                )
            } else {
                Text(
                    text = stringResource(R.string.home_progress, done, required.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        PermissionRow(
            icon = Icons.Outlined.Accessibility,
            title = stringResource(R.string.perm_acc_name),
            desc = stringResource(R.string.perm_acc_desc),
            granted = acc,
            onClick = { Permissions.openAccessibilitySettings(context) },
        )
        PermissionRow(
            icon = Icons.Outlined.TouchApp,
            title = stringResource(R.string.perm_overlay_name),
            desc = stringResource(R.string.perm_overlay_desc),
            granted = overlay,
            onClick = { Permissions.openOverlaySettings(context) },
        )
        PermissionRow(
            icon = Icons.Outlined.Notifications,
            title = stringResource(R.string.perm_notif_name),
            desc = stringResource(R.string.perm_notif_desc),
            granted = notif,
            onClick = {
                if (Build.VERSION.SDK_INT >= 33 && !notif) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    Permissions.openAppDetails(context)
                }
            },
        )
        PermissionRow(
            icon = Icons.Outlined.BatteryFull,
            title = stringResource(R.string.perm_battery_name),
            desc = stringResource(R.string.perm_battery_desc),
            granted = battery,
            onClick = { Permissions.openBatterySettings(context) },
        )

        SectionTitle(stringResource(R.string.home_quick_start))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onOpenMacros,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 12.dp),
            ) {
                Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.action_record))
            }
            FilledTonalButton(
                onClick = onOpenPresets,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 12.dp),
            ) {
                Icon(Icons.Outlined.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.home_action_presets))
            }
        }

        if (playback.status == PlaybackStatus.RUNNING || playback.status == PlaybackStatus.PAUSED) {
            SectionTitle(stringResource(R.string.home_session))
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(
                        icon = Icons.Outlined.PlayArrow,
                        tint = MaterialTheme.colorScheme.primary,
                        container = MaterialTheme.colorScheme.primaryContainer,
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = playback.label,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = buildString {
                                append(
                                    stringResource(
                                        if (playback.status == PlaybackStatus.PAUSED) {
                                            R.string.state_paused
                                        } else {
                                            R.string.state_running
                                        },
                                    ),
                                )
                                append(" · ")
                                append(
                                    if (playback.totalIterations > 0) {
                                        "${playback.iteration}/${playback.totalIterations}"
                                    } else {
                                        "${playback.iteration}"
                                    },
                                )
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (playback.status == PlaybackStatus.PAUSED) {
                                com.speedclick.app.engine.PlaybackEngine.resume()
                            } else {
                                com.speedclick.app.engine.PlaybackEngine.pause()
                            }
                        },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(
                            if (playback.status == PlaybackStatus.PAUSED) Icons.Outlined.PlayArrow else Icons.Outlined.Pause,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            stringResource(
                                if (playback.status == PlaybackStatus.PAUSED) R.string.resume else R.string.pause,
                            ),
                        )
                    }
                    Button(
                        onClick = { vm.stopPlayback() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    ) {
                        Icon(Icons.Outlined.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.stop))
                    }
                }
            }
        }

        SectionTitle(stringResource(R.string.home_tips_title))
        TipCard(
            icon = Icons.Outlined.Info,
            title = stringResource(R.string.tip_restricted_title),
            body = stringResource(R.string.tip_restricted),
        )
        TipCard(
            icon = Icons.Outlined.Info,
            title = stringResource(R.string.tip_apm_title),
            body = stringResource(R.string.tip_apm),
        )
    }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    title: String,
    desc: String,
    granted: Boolean,
    onClick: () -> Unit,
) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(
                icon = icon,
                tint = if (granted) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                container = if (granted) {
                    SuccessGreen.copy(alpha = 0.14f)
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                },
                size = 38,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(
                    desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(8.dp))
            if (granted) {
                StatusPill(
                    text = stringResource(R.string.granted),
                    container = SuccessGreen.copy(alpha = 0.14f),
                    contentColor = SuccessGreen,
                )
            } else {
                Button(
                    onClick = onClick,
                    modifier = Modifier.heightIn(min = 44.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                ) {
                    Text(stringResource(R.string.grant), style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun TipCard(icon: ImageVector, title: String, body: String) {
    AppCard {
        Row {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(8.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    body,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
