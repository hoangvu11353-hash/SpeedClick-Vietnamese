package com.speedclick.app.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.speedclick.app.R
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.util.Permissions

private enum class AppTab(@param:StringRes val labelRes: Int, val icon: ImageVector) {
    HOME(R.string.tab_home, Icons.Outlined.Home),
    MACROS(R.string.tab_macros, Icons.Outlined.TouchApp),
    PRESETS(R.string.tab_presets, Icons.Outlined.Bolt),
    SETTINGS(R.string.tab_settings, Icons.Outlined.Settings),
}

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    var selected by rememberSaveable { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    val playback by vm.playback.collectAsStateWithLifecycle()
    val pendingMacro by vm.pendingMacro.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val msgPlaybackFailed = stringResource(R.string.playback_failed)
    val msgGrant = stringResource(R.string.grant)

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) vm.refreshPermissions()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        vm.refreshPermissions()
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(playback.status) {
        if (playback.status == PlaybackStatus.ERROR) {
            val result = snackbarHostState.showSnackbar(
                message = msgPlaybackFailed,
                actionLabel = msgGrant,
                duration = SnackbarDuration.Short,
            )
            if (result == SnackbarResult.ActionPerformed) {
                Permissions.openAccessibilitySettings(context)
            }
        }
    }

    LaunchedEffect(pendingMacro) {
        if (pendingMacro != null) selected = AppTab.MACROS.ordinal
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                AppTab.entries.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { selected = index },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(stringResource(tab.labelRes)) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            ContentWidth {
                when (selected) {
                    0 -> HomeScreen(
                        vm = vm,
                        onOpenMacros = { selected = AppTab.MACROS.ordinal },
                        onOpenPresets = { selected = AppTab.PRESETS.ordinal },
                    )
                    1 -> MacrosScreen(vm)
                    2 -> PresetsScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }

    if (pendingMacro != null) {
        NameInputDialog(
            title = stringResource(R.string.save_title),
            initial = "",
            onConfirm = { name -> vm.savePendingMacro(name) },
            onDismiss = { vm.dismissPendingMacro() },
        )
    }
}
