package com.speedclick.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.speedclick.app.ui.MainScreen
import com.speedclick.app.ui.theme.SpeedClickTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SpeedClickTheme {
                MainScreen()
            }
        }
    }
}
