package com.speedclick.app.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import com.speedclick.app.data.PlaybackSpec
import com.speedclick.app.data.PlaybackState
import com.speedclick.app.data.PlaybackStatus
import com.speedclick.app.service.ClickerAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

object PlaybackEngine {
    private const val TAG = "SpeedClick"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Volatile
    private var paused = false

    /** Uptime at the moment playback was paused; used to shift the schedule on resume. */
    @Volatile
    private var pauseStartedAt = 0L

    /**
     * Milliseconds added to every scheduled iteration so that time spent paused - or time the
     * process spent frozen - never turns into a backlog. Without this the loop replays every
     * missed iteration as fast as the accessibility APIs allow, which means a 20 second pause
     * resumes at more than double speed until the backlog is drained.
     */
    @Volatile
    private var scheduleShiftMs = 0L

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    fun start(spec: PlaybackSpec) {
        stopInternal()
        paused = false
        pauseStartedAt = 0L
        scheduleShiftMs = 0L
        _state.value = PlaybackState(
            status = PlaybackStatus.RUNNING,
            label = spec.label,
            totalIterations = spec.repeat,
        )
        job = scope.launch {
            try {
                runPlayback(spec)
                _state.value = PlaybackState(status = PlaybackStatus.IDLE)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                Log.e(TAG, "playback failed: ${t.message}", t)
                _state.value = PlaybackState(
                    status = PlaybackStatus.ERROR,
                    label = spec.label,
                    totalIterations = spec.repeat,
                    error = t.message,
                )
            }
        }
    }

    fun pause() {
        if (paused) return
        paused = true
        pauseStartedAt = SystemClock.uptimeMillis()
        if (_state.value.status == PlaybackStatus.RUNNING) {
            _state.update { it.copy(status = PlaybackStatus.PAUSED) }
        }
    }

    fun resume() {
        if (!paused) return
        scheduleShiftMs += (SystemClock.uptimeMillis() - pauseStartedAt).coerceAtLeast(0L)
        paused = false
        pauseStartedAt = 0L
        if (_state.value.status == PlaybackStatus.PAUSED) {
            _state.update { it.copy(status = PlaybackStatus.RUNNING) }
        }
    }

    fun stop() {
        stopInternal()
        _state.value = PlaybackState(status = PlaybackStatus.IDLE)
    }

    private fun stopInternal() {
        job?.cancel()
        job = null
        paused = false
        pauseStartedAt = 0L
        scheduleShiftMs = 0L
    }

    private suspend fun runPlayback(spec: PlaybackSpec) {
        val service = awaitService()
        val limits = GestureChunker.Limits(
            maxGestureDurationMs = GestureDescription.getMaxGestureDuration(),
            maxStrokeCount = GestureDescription.getMaxStrokeCount(),
        )
        val scheduleBase = SystemClock.uptimeMillis() + spec.delayMs.coerceAtLeast(0L)
        val iterationSpan = iterationSpan(spec)

        var iter = 0
        while (true) {
            awaitWhilePaused()
            // Re-read the display size every iteration: it can change mid-session (rotation, split
            // screen, unfolding) and stale metrics would place every tap at the old scale.
            val size = currentScreenSize(service)
            val width = size.first
            val height = size.second
            val chunks = GestureChunker.buildChunks(spec.events, width, height, spec.speed, limits, spec.jitterPx)
            for (chunk in chunks) {
                awaitWhilePaused()
                var target = scheduleBase + scheduleShiftMs + iter * iterationSpan + chunk.startMs
                val lag = SystemClock.uptimeMillis() - target
                if (lag > MAX_LAG_MS) {
                    // The schedule fell far behind (frozen process, doze, heavy stall). Drop the
                    // backlog instead of firing a burst of clicks to catch up.
                    scheduleShiftMs += lag
                    target += lag
                }
                delayUntil(target)
                Log.d(TAG, "dispatch iteration=$iter chunk=${chunk.startMs} strokes=${chunk.strokes.size}")
                dispatchWithRetry(service, chunk, width, height, iter)
            }
            iter++
            _state.update { it.copy(iteration = iter) }
            if (spec.repeat > 0 && iter >= spec.repeat) break
        }
    }

    /**
     * Current display size in the active orientation. `getRealMetrics` on a service context can
     * lag behind rotation changes, so the modern WindowMetrics API is preferred.
     */
    private fun currentScreenSize(service: ClickerAccessibilityService): Pair<Float, Float> {
        val wm = service.getSystemService(WindowManager::class.java)
        val bounds = wm.currentWindowMetrics.bounds
        if (bounds.width() > 0 && bounds.height() > 0) {
            return bounds.width().toFloat() to bounds.height().toFloat()
        }
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        return metrics.widthPixels.toFloat() to metrics.heightPixels.toFloat()
    }

    private fun iterationSpan(spec: PlaybackSpec): Long {
        val scaled = ((spec.events.maxOfOrNull { it.t } ?: 0L) / spec.speed.coerceIn(0.5f, 5f)).toLong()
        return scaled.coerceAtLeast(1L) + spec.intervalMs.coerceAtLeast(0L)
    }

    /**
     * A gesture is cancelled whenever the user touches the screen (or another service injects
     * input), which is normal during everyday use. Retry a few times instead of ending the
     * whole session, and only give up when it keeps failing.
     */
    private suspend fun dispatchWithRetry(
        service: ClickerAccessibilityService,
        chunk: Chunk,
        width: Float,
        height: Float,
        iteration: Int,
    ) {
        var attempt = 0
        while (true) {
            if (dispatch(service, toGesture(chunk, width, height))) return
            attempt++
            if (attempt >= MAX_DISPATCH_ATTEMPTS) {
                throw IllegalStateException("gesture dispatch failed after $attempt attempts")
            }
            // Back off a little more each time: a finger resting on the screen (or any other
            // injected touch) makes dispatchGesture return false for as long as it lasts, so a
            // fixed 150 ms retry gave up after roughly half a second.
            val backoff = RETRY_DELAYS_MS[minOf(attempt - 1, RETRY_DELAYS_MS.size - 1)]
            Log.d(TAG, "gesture cancelled on iteration=$iteration, retry $attempt in ${backoff}ms")
            delay(backoff)
        }
    }

    private suspend fun awaitService(): ClickerAccessibilityService {
        repeat(100) {
            ClickerAccessibilityService.instance?.let { return it }
            delay(50)
        }
        throw IllegalStateException("Accessibility service is not enabled")
    }

    private suspend fun awaitWhilePaused() {
        while (paused) delay(50)
    }

    private suspend fun delayUntil(target: Long) {
        while (true) {
            awaitWhilePaused()
            val remaining = target - SystemClock.uptimeMillis()
            if (remaining <= 0) return
            delay(minOf(remaining, 100L))
        }
    }

    /**
     * Dispatches one gesture and waits for its callback, but never forever: some OEM builds
     * occasionally drop the completion callback (observed on Android 17 / ColorOS, where the
     * log stops right after `dispatchGesture returned true`), and without a timeout the whole
     * session would sit there doing nothing until the user stops it by hand.
     */
    private suspend fun dispatch(service: ClickerAccessibilityService, gesture: GestureDescription): Boolean {
        val timeout = dispatchTimeoutMs(gestureDurationMs(gesture))
        val completed = withTimeoutOrNull(timeout) { dispatchInternal(service, gesture) }
        if (completed == null) {
            Log.w(TAG, "gesture callback timed out after ${timeout}ms, treating it as cancelled")
            return false
        }
        return completed
    }

    private suspend fun dispatchInternal(
        service: ClickerAccessibilityService,
        gesture: GestureDescription,
    ): Boolean = suspendCancellableCoroutine { cont ->
            val ok = service.dispatchGesture(
                gesture,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) {
                        Log.d(TAG, "gesture completed")
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(g: GestureDescription?) {
                        Log.d(TAG, "gesture cancelled")
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null,
            )
            Log.d(TAG, "dispatchGesture returned $ok")
            if (!ok && cont.isActive) cont.resume(false)
        }

    /** Longest stroke in the gesture, used to size the callback timeout. */
    private fun gestureDurationMs(gesture: GestureDescription): Long {
        var longest = 0L
        for (i in 0 until gesture.strokeCount) {
            val stroke = gesture.getStroke(i)
            longest = maxOf(longest, stroke.startTime + stroke.duration)
        }
        return longest
    }

    private fun dispatchTimeoutMs(gestureDurationMs: Long): Long =
        (gestureDurationMs + CALLBACK_GRACE_MS).coerceAtLeast(MIN_CALLBACK_TIMEOUT_MS)

    private fun toGesture(chunk: Chunk, width: Float, height: Float): GestureDescription {
        val builder = GestureDescription.Builder()
        chunk.strokes.forEach { stroke ->
            val path = Path()
            stroke.points.forEachIndexed { i, p ->
                val x = p.x.coerceIn(0f, width - 1f)
                val y = p.y.coerceIn(0f, height - 1f)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val duration = (stroke.endMs - stroke.startMs).coerceIn(1L, GestureDescription.getMaxGestureDuration())
            val bounds = android.graphics.RectF()
            path.computeBounds(bounds, true)
            Log.d(
                TAG,
                "stroke points=${stroke.points.size} from=(${bounds.left},${bounds.top}) " +
                    "to=(${bounds.right},${bounds.bottom}) start=${stroke.startMs} duration=$duration " +
                    "screen=${width.toInt()}x${height.toInt()}",
            )
            builder.addStroke(GestureDescription.StrokeDescription(path, stroke.startMs, duration))
        }
        return builder.build()
    }

    private const val MAX_DISPATCH_ATTEMPTS = 5

    /** Backoff between dispatch attempts; the last value repeats for any further attempt. */
    private val RETRY_DELAYS_MS = longArrayOf(150L, 300L, 600L, 1_200L)

    /** Grace period added to the gesture duration before the callback is considered lost. */
    private const val CALLBACK_GRACE_MS = 1_500L
    private const val MIN_CALLBACK_TIMEOUT_MS = 2_000L

    /**
     * Largest allowed lag before the schedule is re-anchored. Small stutters are absorbed by
     * dispatching a little faster for a moment; anything bigger would become a visible burst.
     */
    private const val MAX_LAG_MS = 250L
}
