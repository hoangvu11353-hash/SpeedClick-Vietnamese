package com.speedclick.app.overlay

import com.speedclick.app.data.Pt
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object PickerBus {
    private val _results = MutableSharedFlow<List<Pt>?>(replay = 0, extraBufferCapacity = 4)
    val results: SharedFlow<List<Pt>?> = _results.asSharedFlow()

    fun submit(points: List<Pt>?) {
        _results.tryEmit(points)
    }
}
