package com.speedclick.app.ui

import java.util.Locale

fun formatDuration(ms: Long): String {
    val clamped = ms.coerceAtLeast(0L)
    return if (clamped < 60_000L) {
        String.format(Locale.US, "%.1fs", clamped / 1000f)
    } else {
        String.format(Locale.US, "%dm%02.0fs", clamped / 60_000L, (clamped % 60_000L) / 1000f)
    }
}
