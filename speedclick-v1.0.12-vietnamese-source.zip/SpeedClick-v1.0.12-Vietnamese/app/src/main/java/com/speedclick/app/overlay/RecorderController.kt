package com.speedclick.app.overlay

import android.os.SystemClock
import android.view.MotionEvent
import com.speedclick.app.data.Macro
import com.speedclick.app.data.TouchEvent
import com.speedclick.app.engine.GestureChunker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

object RecorderController {
    enum class Phase { IDLE, READY, RECORDING, PAUSED }

    data class RecordState(val phase: Phase = Phase.IDLE)

    private val _state = MutableStateFlow(RecordState())
    val state: StateFlow<RecordState> = _state.asStateFlow()

    private val _pendingMacro = MutableStateFlow<Macro?>(null)
    val pendingMacro: StateFlow<Macro?> = _pendingMacro.asStateFlow()

    private val events = mutableListOf<TouchEvent>()
    private var startUptime = 0L
    private var pausedAt = 0L
    private var pausedTotal = 0L
    private var screenW = 0
    private var screenH = 0

    /**
     * Supplies the current display size. The overlay service points this at the live window
     * metrics so a rotation/resize in the middle of a recording cannot shift every later point
     * (the size captured at start would otherwise be reused for all of them).
     */
    @Volatile
    var sizeProvider: (() -> Pair<Int, Int>)? = null

    fun ready() {
        resetInternals()
        _state.value = RecordState(Phase.READY)
    }

    fun start(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        events.clear()
        screenW = width
        screenH = height
        startUptime = SystemClock.uptimeMillis()
        pausedAt = 0L
        pausedTotal = 0L
        _state.value = RecordState(Phase.RECORDING)
    }

    fun pause() {
        if (_state.value.phase == Phase.RECORDING) {
            pausedAt = SystemClock.uptimeMillis()
            _state.value = RecordState(Phase.PAUSED)
        }
    }

    fun resume() {
        if (_state.value.phase == Phase.PAUSED) {
            pausedTotal += SystemClock.uptimeMillis() - pausedAt
            _state.value = RecordState(Phase.RECORDING)
        }
    }

    fun stop() {
        if (events.isEmpty()) {
            cancel()
            return
        }
        val compressed = GestureChunker.compress(events)
        val macro = Macro(
            id = UUID.randomUUID().toString(),
            name = "",
            createdAt = System.currentTimeMillis(),
            durationMs = compressed.maxOfOrNull { it.t } ?: 0L,
            events = compressed,
        )
        _pendingMacro.value = macro
        resetInternals()
    }

    fun cancel() {
        resetInternals()
    }

    fun clearPending() {
        _pendingMacro.value = null
    }

    fun onTouch(event: MotionEvent) {
        if (_state.value.phase != Phase.RECORDING) return
        val now = (SystemClock.uptimeMillis() - startUptime - pausedTotal).coerceAtLeast(0L)
        val action = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> TouchAction.DOWN
            MotionEvent.ACTION_UP -> TouchAction.UP
            MotionEvent.ACTION_MOVE -> TouchAction.MOVE
            MotionEvent.ACTION_CANCEL -> TouchAction.CANCEL
            MotionEvent.ACTION_POINTER_DOWN -> TouchAction.POINTER_DOWN
            MotionEvent.ACTION_POINTER_UP -> TouchAction.POINTER_UP
            else -> return
        }
        val pointerCount = event.pointerCount
        val ids = IntArray(pointerCount) { event.getPointerId(it) }
        // Screen (raw) coordinates: the capture window can be inset - on ColorOS/Android 17 it
        // starts below the status bar (141 px on a 560 dpi phone), and view-local coordinates would
        // record every touch that much too high, so the replay landed 40 dp above the finger.
        val xs = FloatArray(pointerCount) { event.getRawX(it) }
        val ys = FloatArray(pointerCount) { event.getRawY(it) }

        val live = sizeProvider?.invoke()
        val width = live?.first?.takeIf { it > 0 } ?: screenW
        val height = live?.second?.takeIf { it > 0 } ?: screenH
        when (val outcome = TouchSampler.sample(
            elapsedMs = now,
            action = action,
            actionIndex = event.actionIndex,
            pointerIds = ids,
            xs = xs,
            ys = ys,
            screenWidth = width,
            screenHeight = height,
        )) {
            TouchSampler.Outcome.OverBudget -> stop()
            is TouchSampler.Outcome.Sampled -> events.addAll(outcome.events)
        }
    }

    private fun resetInternals() {
        events.clear()
        startUptime = 0L
        pausedAt = 0L
        pausedTotal = 0L
        screenW = 0
        screenH = 0
        _state.value = RecordState(Phase.IDLE)
    }
}
