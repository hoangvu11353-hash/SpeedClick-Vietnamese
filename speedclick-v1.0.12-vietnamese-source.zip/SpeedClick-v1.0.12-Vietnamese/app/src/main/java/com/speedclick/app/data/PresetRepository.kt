package com.speedclick.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class PresetRepository(context: Context) {
    private val file = File(context.filesDir, "presets.json")

    private val _configs = MutableStateFlow(load())
    val configs: StateFlow<Map<PresetConfig.PresetType, PresetConfig>> = _configs.asStateFlow()

    fun config(type: PresetConfig.PresetType): PresetConfig = _configs.value[type] ?: defaults.getValue(type)

    fun update(config: PresetConfig) {
        _configs.value = _configs.value + (config.type to config)
        save()
    }

    private fun load(): Map<PresetConfig.PresetType, PresetConfig> {
        val stored = runCatching { JsonCodec.decode<List<PresetConfig>>(file.readText()) }.getOrNull() ?: emptyList()
        val map = stored.associateBy { it.type }.toMutableMap()
        defaults.forEach { (k, v) -> map.putIfAbsent(k, v) }
        return map
    }

    private fun save() {
        runCatching { file.writeText(JsonCodec.encode(_configs.value.values.toList())) }
    }

    companion object {
        val defaults: Map<PresetConfig.PresetType, PresetConfig> = mapOf(
            PresetConfig.PresetType.SINGLE_TAP to PresetConfig(
                type = PresetConfig.PresetType.SINGLE_TAP,
                points = listOf(Pt(0.5f, 0.5f)),
                intervalMs = 50,
            ),
            PresetConfig.PresetType.MULTI_TAP to PresetConfig(
                type = PresetConfig.PresetType.MULTI_TAP,
                points = listOf(Pt(0.35f, 0.5f), Pt(0.65f, 0.5f)),
                intervalMs = 100,
            ),
            PresetConfig.PresetType.DOUBLE_TAP to PresetConfig(
                type = PresetConfig.PresetType.DOUBLE_TAP,
                points = listOf(Pt(0.5f, 0.5f)),
                intervalMs = 300,
            ),
            PresetConfig.PresetType.LONG_PRESS to PresetConfig(
                type = PresetConfig.PresetType.LONG_PRESS,
                points = listOf(Pt(0.5f, 0.5f)),
                intervalMs = 200,
            ),
            PresetConfig.PresetType.SWIPE to PresetConfig(
                type = PresetConfig.PresetType.SWIPE,
                points = listOf(Pt(0.5f, 0.35f), Pt(0.5f, 0.65f)),
                intervalMs = 200,
            ),
        )
    }
}
