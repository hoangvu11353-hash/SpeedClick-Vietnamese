package com.speedclick.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    private val jitterKey = floatPreferencesKey("jitter_px")
    private val onboardingKey = booleanPreferencesKey("onboarding_done")

    val jitterPx: Flow<Float> = context.dataStore.data.map { it[jitterKey] ?: 0f }
    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[onboardingKey] ?: false }

    suspend fun setJitter(px: Float) {
        context.dataStore.edit { it[jitterKey] = px.coerceIn(0f, 30f) }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { it[onboardingKey] = done }
    }
}
