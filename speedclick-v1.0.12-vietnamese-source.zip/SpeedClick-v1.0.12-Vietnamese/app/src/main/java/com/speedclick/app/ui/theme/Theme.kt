package com.speedclick.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BrandBlue = Color(0xFF2F6BFF)
val SuccessGreen = Color(0xFF2FA45C)
val DangerRed = Color(0xFFE5484D)

private val LightColors = lightColorScheme(
    primary = BrandBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE5FF),
    onPrimaryContainer = Color(0xFF0B2B6F),
    secondary = Color(0xFF5A6478),
    background = Color(0xFFF6F7FB),
    onBackground = Color(0xFF1A1D26),
    surface = Color.White,
    onSurface = Color(0xFF1A1D26),
    surfaceVariant = Color(0xFFEDF0F6),
    onSurfaceVariant = Color(0xFF4A5162),
    outline = Color(0xFFC4CAD6),
    error = Color(0xFFE5484D),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9BB5FF),
    onPrimary = Color(0xFF102A66),
    background = Color(0xFF10131B),
    onBackground = Color(0xFFE5E8F0),
    surface = Color(0xFF161A24),
    onSurface = Color(0xFFE5E8F0),
    surfaceVariant = Color(0xFF232937),
    onSurfaceVariant = Color(0xFFB9C0CE),
    outline = Color(0xFF3A4252),
    error = Color(0xFFFFB4AB),
)

@Composable
fun SpeedClickTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
