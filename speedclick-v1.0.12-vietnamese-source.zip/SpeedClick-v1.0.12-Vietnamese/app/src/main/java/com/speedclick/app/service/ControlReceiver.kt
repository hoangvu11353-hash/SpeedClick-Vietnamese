package com.speedclick.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.speedclick.app.engine.PlaybackEngine
import com.speedclick.app.overlay.RecorderController

class ControlReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val recording = RecorderController.state.value.phase.let {
            it == RecorderController.Phase.RECORDING || it == RecorderController.Phase.PAUSED
        }
        when (intent.action) {
            ACTION_PAUSE -> if (recording) RecorderController.pause() else PlaybackEngine.pause()
            ACTION_RESUME -> if (recording) RecorderController.resume() else PlaybackEngine.resume()
            ACTION_STOP -> {
                if (recording) RecorderController.stop() else RecorderController.cancel()
                PlaybackEngine.stop()
            }
        }
    }

    companion object {
        const val ACTION_PAUSE = "com.speedclick.app.action.PAUSE"
        const val ACTION_RESUME = "com.speedclick.app.action.RESUME"
        const val ACTION_STOP = "com.speedclick.app.action.STOP"
    }
}
