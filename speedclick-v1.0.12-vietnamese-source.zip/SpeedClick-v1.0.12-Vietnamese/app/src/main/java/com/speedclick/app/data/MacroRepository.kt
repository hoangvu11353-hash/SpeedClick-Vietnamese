package com.speedclick.app.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class MacroRepository(context: Context) {
    private val dir = File(context.filesDir, "macros").apply { mkdirs() }
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _macros = MutableStateFlow<List<Macro>>(emptyList())
    val macros: StateFlow<List<Macro>> = _macros.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    init {
        // Loading happens off the main thread so a large macro library cannot delay startup.
        ioScope.launch {
            val fromDisk = loadAll()
            // Keep anything that was saved while the initial load was in flight.
            val merged = (fromDisk + _macros.value)
                .distinctBy { it.id }
                .sortedByDescending { it.createdAt }
            _macros.value = merged
            _loaded.value = true
        }
    }

    fun loadAll(): List<Macro> =
        dir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { runCatching { JsonCodec.decode<Macro>(it.readText()) }.getOrNull() }
            ?.sortedByDescending { it.createdAt }
            ?: emptyList()

    fun save(events: List<TouchEvent>, name: String): Macro {
        val macro = Macro(
            id = UUID.randomUUID().toString(),
            name = name,
            createdAt = System.currentTimeMillis(),
            durationMs = events.maxOfOrNull { it.t } ?: 0L,
            events = events,
        )
        _macros.update { (listOf(macro) + it.filter { m -> m.id != macro.id }).sortedByDescending { m -> m.createdAt } }
        writeAsync(macro)
        return macro
    }

    fun rename(id: String, name: String) {
        val target = _macros.value.find { it.id == id } ?: return
        val updated = target.copy(name = name)
        _macros.update { list -> list.map { if (it.id == id) updated else it } }
        writeAsync(updated)
    }

    fun delete(id: String) {
        _macros.update { it.filter { m -> m.id != id } }
        ioScope.launch { runCatching { File(dir, "$id.json").delete() } }
    }

    fun exportMacro(id: String): String? =
        _macros.value.find { it.id == id }?.let { JsonCodec.encode(it) }

    fun exportAll(): String = JsonCodec.encode(MacroList(macros = _macros.value))

    fun importText(text: String): Int {
        val list = runCatching { JsonCodec.decode<MacroList>(text) }.getOrNull()
        return if (list != null) {
            importAll(list.macros)
        } else {
            val macro = JsonCodec.decode<Macro>(text)
            require(macro.events.isNotEmpty()) { "macro has no events" }
            _macros.update { (listOf(macro) + it.filter { m -> m.id != macro.id }).sortedByDescending { m -> m.createdAt } }
            writeAsync(macro)
            1
        }
    }

    private fun importAll(list: List<Macro>): Int {
        var count = 0
        list.forEach { m ->
            if (m.events.isNotEmpty()) {
                runCatching { write(m) }
                count++
            }
        }
        if (count > 0) _macros.value = loadAll()
        return count
    }

    private fun write(macro: Macro) {
        File(dir, "${macro.id}.json").writeText(JsonCodec.encode(macro))
    }

    private fun writeAsync(macro: Macro) {
        ioScope.launch { runCatching { write(macro) } }
    }
}
