package com.speedclick.app.data

import kotlinx.serialization.json.Json

object JsonCodec {
    val json = Json {
        encodeDefaults = true
        ignoreUnknownKeys = true
        prettyPrint = false
    }

    inline fun <reified T> decode(text: String): T = json.decodeFromString(text)

    inline fun <reified T> encode(value: T): String = json.encodeToString(value)
}
