package com.speedclick.app.ui

import com.speedclick.app.data.PresetConfig
import com.speedclick.app.data.PresetRepository

object PresetRepositoryDefaults {
    fun of(type: PresetConfig.PresetType): PresetConfig =
        PresetRepository.defaults.getValue(type)
}
