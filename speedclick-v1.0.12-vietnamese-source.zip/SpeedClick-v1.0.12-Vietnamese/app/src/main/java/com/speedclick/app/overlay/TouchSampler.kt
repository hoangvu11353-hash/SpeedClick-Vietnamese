package com.speedclick.app.overlay

import com.speedclick.app.data.TouchEvent

/** MotionEvent action kinds, decoupled from the Android framework so the logic stays testable. */
enum class TouchAction { DOWN, UP, MOVE, CANCEL, POINTER_DOWN, POINTER_UP }

/**
 * Turns a raw touch batch into normalized macro events.
 *
 * Pure logic: the caller passes elapsed time and pointer data, so results are deterministic
 * and can be verified with plain JVM unit tests.
 */
object TouchSampler {

    /** Hard cap so a forgotten recording session cannot exhaust memory. */
    const val MAX_RECORD_MS = 30 * 60 * 1000L

    sealed interface Outcome {
        data class Sampled(val events: List<TouchEvent>) : Outcome
        data object OverBudget : Outcome
    }

    fun sample(
        elapsedMs: Long,
        action: TouchAction,
        actionIndex: Int,
        pointerIds: IntArray,
        xs: FloatArray,
        ys: FloatArray,
        screenWidth: Int,
        screenHeight: Int,
        maxRecordMs: Long = MAX_RECORD_MS,
    ): Outcome {
        if (elapsedMs >= maxRecordMs) return Outcome.OverBudget
        if (screenWidth <= 0 || screenHeight <= 0) return Outcome.Sampled(emptyList())

        val time = elapsedMs.coerceAtLeast(0L)
        val index = if (actionIndex in pointerIds.indices) actionIndex else -1
        val events = when (action) {
            TouchAction.DOWN, TouchAction.POINTER_DOWN ->
                if (index < 0) {
                    emptyList()
                } else {
                    listOf(event(TouchEvent.EventType.DOWN, index, time, pointerIds, xs, ys, screenWidth, screenHeight))
                }

            TouchAction.UP, TouchAction.POINTER_UP ->
                if (index < 0) {
                    emptyList()
                } else {
                    listOf(event(TouchEvent.EventType.UP, index, time, pointerIds, xs, ys, screenWidth, screenHeight))
                }

            TouchAction.CANCEL, TouchAction.MOVE -> {
                val type = if (action == TouchAction.CANCEL) TouchEvent.EventType.UP else TouchEvent.EventType.MOVE
                pointerIds.indices.map { i ->
                    event(type, i, time, pointerIds, xs, ys, screenWidth, screenHeight)
                }
            }
        }
        return Outcome.Sampled(events)
    }

    private fun event(
        type: TouchEvent.EventType,
        index: Int,
        time: Long,
        pointerIds: IntArray,
        xs: FloatArray,
        ys: FloatArray,
        screenWidth: Int,
        screenHeight: Int,
    ): TouchEvent = TouchEvent(
        type = type,
        x = (xs[index] / screenWidth).coerceIn(0f, 1f),
        y = (ys[index] / screenHeight).coerceIn(0f, 1f),
        t = time,
        pointer = pointerIds[index],
    )
}
