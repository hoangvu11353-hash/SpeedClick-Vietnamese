package com.speedclick.app.data

import kotlinx.serialization.Serializable

@Serializable
data class Macro(
    val schemaVersion: Int = 1,
    val id: String,
    val name: String,
    val createdAt: Long,
    val durationMs: Long,
    val events: List<TouchEvent>,
)

@Serializable
data class TouchEvent(
    val type: EventType,
    val x: Float,
    val y: Float,
    val t: Long,
    val pointer: Int = 0,
) {
    @Serializable
    enum class EventType { DOWN, MOVE, UP }
}

@Serializable
data class Pt(val x: Float, val y: Float)

@Serializable
data class PresetConfig(
    val type: PresetType,
    val points: List<Pt> = emptyList(),
    val delayMs: Long = 0,
    val repeat: Int = 0,
    val intervalMs: Long = 100,
    val speed: Float = 1f,
    val holdMs: Long = 800,
    val swipeMs: Long = 500,
) {
    @Serializable
    enum class PresetType { SINGLE_TAP, MULTI_TAP, DOUBLE_TAP, LONG_PRESS, SWIPE }
}

@Serializable
data class MacroList(val schemaVersion: Int = 1, val macros: List<Macro>)

data class PlaybackSpec(
    val label: String,
    val events: List<TouchEvent>,
    val delayMs: Long,
    val repeat: Int,
    val intervalMs: Long,
    val speed: Float,
    val jitterPx: Float,
)

enum class PlaybackStatus { IDLE, RUNNING, PAUSED, ERROR }

data class PlaybackState(
    val status: PlaybackStatus = PlaybackStatus.IDLE,
    val label: String = "",
    val iteration: Int = 0,
    val totalIterations: Int = 0,
    val error: String? = null,
)
