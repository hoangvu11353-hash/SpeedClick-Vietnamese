package com.speedclick.app

import android.app.Application
import android.content.Context
import com.speedclick.app.data.MacroRepository
import com.speedclick.app.data.PresetRepository
import com.speedclick.app.data.SettingsRepository

class SpeedClickApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val macroRepository = MacroRepository(appContext)
    val presetRepository = PresetRepository(appContext)
    val settingsRepository = SettingsRepository(appContext)
}
