package com.speedclick.app.engine

import com.speedclick.app.data.Pt
import com.speedclick.app.data.PresetConfig
import com.speedclick.app.data.TouchEvent

object PresetEngine {

    fun buildIteration(config: PresetConfig): List<TouchEvent> {
        val points = config.points
        require(points.isNotEmpty()) { "preset has no points" }
        return when (config.type) {
            PresetConfig.PresetType.SINGLE_TAP -> tap(points.first())
            PresetConfig.PresetType.MULTI_TAP -> points.flatMapIndexed { i, p -> tap(p, pointer = i) }
            PresetConfig.PresetType.DOUBLE_TAP -> tap(points.first()) + tap(points.first(), at = 120L)
            PresetConfig.PresetType.LONG_PRESS -> {
                val p = points.first()
                listOf(
                    TouchEvent(TouchEvent.EventType.DOWN, p.x, p.y, 0L, 0),
                    TouchEvent(TouchEvent.EventType.UP, p.x, p.y, config.holdMs.coerceAtLeast(50L), 0),
                )
            }
            PresetConfig.PresetType.SWIPE -> {
                val a = points.first()
                val b = points.last()
                val dur = config.swipeMs.coerceAtLeast(50L)
                listOf(
                    TouchEvent(TouchEvent.EventType.DOWN, a.x, a.y, 0L, 0),
                    TouchEvent(TouchEvent.EventType.MOVE, a.x + (b.x - a.x) * 0.5f, a.y + (b.y - a.y) * 0.5f, dur / 2, 0),
                    TouchEvent(TouchEvent.EventType.UP, b.x, b.y, dur, 0),
                )
            }
        }
    }

    fun iterationDuration(config: PresetConfig): Long = when (config.type) {
        PresetConfig.PresetType.SINGLE_TAP, PresetConfig.PresetType.MULTI_TAP -> 40L
        PresetConfig.PresetType.DOUBLE_TAP -> 160L
        PresetConfig.PresetType.LONG_PRESS -> config.holdMs.coerceAtLeast(50L)
        PresetConfig.PresetType.SWIPE -> config.swipeMs.coerceAtLeast(50L)
    }

    private fun tap(p: Pt, pointer: Int = 0, at: Long = 0L): List<TouchEvent> = listOf(
        TouchEvent(TouchEvent.EventType.DOWN, p.x, p.y, at, pointer),
        TouchEvent(TouchEvent.EventType.UP, p.x, p.y, at + 40L, pointer),
    )
}
