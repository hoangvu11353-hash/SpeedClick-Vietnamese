package com.speedclick.app.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.TrendingFlat
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.PanTool
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speedclick.app.R
import com.speedclick.app.data.PresetConfig
import com.speedclick.app.overlay.PickerBus
import com.speedclick.app.service.OverlayService
import com.speedclick.app.util.Permissions
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun PresetsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val configs by vm.presetConfigs.collectAsStateWithLifecycle()
    val jitter by vm.jitterPx.collectAsStateWithLifecycle(initialValue = 0f)
    var selected by remember { mutableStateOf<PresetConfig.PresetType?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val msgPlaybackFailed = stringResource(R.string.playback_failed)
    val msgGrant = stringResource(R.string.grant)

    Box(Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            ScreenHeader(
                title = stringResource(R.string.presets_title),
                subtitle = stringResource(R.string.presets_subtitle),
            )
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
            ) {
                items(PresetConfig.PresetType.entries) { type ->
                    val config = configs[type] ?: PresetRepositoryDefaults.of(type)
                    PresetCard(type = type, config = config, onClick = { selected = type })
                }
            }
        }
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
        )
    }

    selected?.let { type ->
        val config = configs[type] ?: PresetRepositoryDefaults.of(type)
        PresetDetailDialog(
            config = config,
            onChange = vm::updatePreset,
            onAskPermission = {
                scope.launch {
                    val result = snackbarHostState.showSnackbar(
                        message = msgPlaybackFailed,
                        actionLabel = msgGrant,
                        duration = SnackbarDuration.Short,
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        Permissions.openAccessibilitySettings(context)
                    }
                }
            },
            onPlay = { vm.playPreset(config, jitter) },
            canPlay = vm.isAccessibilityReady(),
            onDismiss = { selected = null },
        )
    }
}

@Composable
private fun PresetCard(type: PresetConfig.PresetType, config: PresetConfig, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconBadge(
                icon = presetIcon(type),
                tint = MaterialTheme.colorScheme.primary,
                container = MaterialTheme.colorScheme.primaryContainer,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(presetLabelRes(type)),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    stringResource(presetDescRes(type)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (config.points.isEmpty()) {
                        stringResource(R.string.points_none)
                    } else {
                        pluralStringResource(R.plurals.points_count, config.points.size, config.points.size)
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(2.dp))
                Icon(
                    Icons.Outlined.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
internal fun PresetDetailDialog(
    config: PresetConfig,
    onChange: (PresetConfig) -> Unit,
    onAskPermission: () -> Unit,
    onPlay: () -> Unit,
    canPlay: Boolean,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    var pickRequest by remember { mutableIntStateOf(0) }
    // Dialog windows wrap their content, so an unbounded scrollable column would push the
    // action buttons off-screen on short displays (landscape phones, split screen, small windows).
    val maxContentHeight = (LocalConfiguration.current.screenHeightDp * 0.5f).dp

    LaunchedEffect(pickRequest) {
        if (pickRequest > 0) {
            PickerBus.results.collect { points ->
                pickRequest = 0
                if (points != null) onChange(config.copy(points = points))
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(
                    icon = presetIcon(config.type),
                    tint = MaterialTheme.colorScheme.primary,
                    container = MaterialTheme.colorScheme.primaryContainer,
                    size = 36,
                )
                Spacer(Modifier.width(10.dp))
                Text(stringResource(presetLabelRes(config.type)))
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = maxContentHeight)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                FilledTonalButton(
                    onClick = {
                        pickRequest++
                        OverlayService.start(context, OverlayService.ACTION_PICKER, pickerModeFor(config.type))
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Outlined.MyLocation, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.pick_points))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(
                        text = if (config.points.isEmpty()) {
                        stringResource(R.string.points_none)
                    } else {
                        pluralStringResource(R.plurals.points_count, config.points.size, config.points.size)
                    },
                        container = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                SectionTitle(stringResource(R.string.preset_params))

                NumberField(
                    label = stringResource(R.string.param_delay),
                    value = (config.delayMs / 1000L).toString(),
                    keyboardType = KeyboardType.Number,
                    onValueChange = { text ->
                        onChange(config.copy(delayMs = ((text.toLongOrNull() ?: 0L).coerceIn(0L, 60L)) * 1000L))
                    },
                )
                NumberField(
                    label = stringResource(R.string.param_repeat),
                    value = config.repeat.toString(),
                    keyboardType = KeyboardType.Number,
                    onValueChange = { text ->
                        onChange(config.copy(repeat = (text.toIntOrNull() ?: 0).coerceAtLeast(0)))
                    },
                )
                NumberField(
                    label = stringResource(R.string.param_interval),
                    value = config.intervalMs.toString(),
                    keyboardType = KeyboardType.Number,
                    onValueChange = { text ->
                        onChange(config.copy(intervalMs = (text.toLongOrNull() ?: 0L).coerceIn(0L, 10_000L)))
                    },
                )
                Text(
                    text = stringResource(
                        R.string.param_speed_value,
                        String.format(Locale.US, "%.1f", config.speed),
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                )
                Slider(
                    value = config.speed.coerceIn(0.5f, 5f),
                    onValueChange = { v -> onChange(config.copy(speed = v)) },
                    valueRange = 0.5f..5f,
                    steps = 8,
                )

                if (config.type == PresetConfig.PresetType.LONG_PRESS) {
                    NumberField(
                        label = stringResource(R.string.param_hold),
                        value = config.holdMs.toString(),
                        keyboardType = KeyboardType.Number,
                        onValueChange = { text ->
                            onChange(config.copy(holdMs = (text.toLongOrNull() ?: 800L).coerceIn(50L, 60_000L)))
                        },
                    )
                }
                if (config.type == PresetConfig.PresetType.SWIPE) {
                    NumberField(
                        label = stringResource(R.string.param_swipe_dur),
                        value = config.swipeMs.toString(),
                        keyboardType = KeyboardType.Number,
                        onValueChange = { text ->
                            onChange(config.copy(swipeMs = (text.toLongOrNull() ?: 500L).coerceIn(50L, 60_000L)))
                        },
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = { if (canPlay) onPlay() else onAskPermission() }) {
                Text(stringResource(R.string.preset_run))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        },
    )
}

@Composable
private fun NumberField(
    label: String,
    value: String,
    keyboardType: KeyboardType,
    onValueChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth(),
    )
}

private fun pickerModeFor(type: PresetConfig.PresetType): String = when (type) {
    PresetConfig.PresetType.MULTI_TAP -> "multi"
    PresetConfig.PresetType.SWIPE -> "swipe"
    else -> "point"
}

private fun presetIcon(type: PresetConfig.PresetType): ImageVector = when (type) {
    PresetConfig.PresetType.SINGLE_TAP -> Icons.Outlined.TouchApp
    PresetConfig.PresetType.MULTI_TAP -> Icons.Outlined.Apps
    PresetConfig.PresetType.DOUBLE_TAP -> Icons.Outlined.Repeat
    PresetConfig.PresetType.LONG_PRESS -> Icons.Outlined.PanTool
    PresetConfig.PresetType.SWIPE -> Icons.AutoMirrored.Outlined.TrendingFlat
}

@StringRes
private fun presetLabelRes(type: PresetConfig.PresetType): Int = when (type) {
    PresetConfig.PresetType.SINGLE_TAP -> R.string.preset_single_tap
    PresetConfig.PresetType.MULTI_TAP -> R.string.preset_multi_tap
    PresetConfig.PresetType.DOUBLE_TAP -> R.string.preset_double_tap
    PresetConfig.PresetType.LONG_PRESS -> R.string.preset_long_press
    PresetConfig.PresetType.SWIPE -> R.string.preset_swipe
}

@StringRes
private fun presetDescRes(type: PresetConfig.PresetType): Int = when (type) {
    PresetConfig.PresetType.SINGLE_TAP -> R.string.preset_single_tap_desc
    PresetConfig.PresetType.MULTI_TAP -> R.string.preset_multi_tap_desc
    PresetConfig.PresetType.DOUBLE_TAP -> R.string.preset_double_tap_desc
    PresetConfig.PresetType.LONG_PRESS -> R.string.preset_long_press_desc
    PresetConfig.PresetType.SWIPE -> R.string.preset_swipe_desc
}
