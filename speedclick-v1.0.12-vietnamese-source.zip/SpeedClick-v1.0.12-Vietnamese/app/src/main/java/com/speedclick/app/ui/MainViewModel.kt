package com.speedclick.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.speedclick.app.R
import com.speedclick.app.SpeedClickApp
import com.speedclick.app.data.Macro
import com.speedclick.app.data.PlaybackSpec
import com.speedclick.app.data.PresetConfig
import com.speedclick.app.engine.PlaybackEngine
import com.speedclick.app.engine.PresetEngine
import com.speedclick.app.overlay.RecorderController
import com.speedclick.app.service.OverlayService
import com.speedclick.app.util.Permissions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as SpeedClickApp).container

    val macros = container.macroRepository.macros
    val macrosLoaded = container.macroRepository.loaded
    val presetConfigs = container.presetRepository.configs
    val jitterPx = container.settingsRepository.jitterPx
    val playback = PlaybackEngine.state
    val recorder = RecorderController.state
    val pendingMacro = RecorderController.pendingMacro

    private val _accessibilityGranted = MutableStateFlow(false)
    val accessibilityGranted: StateFlow<Boolean> = _accessibilityGranted.asStateFlow()

    private val _overlayGranted = MutableStateFlow(false)
    val overlayGranted: StateFlow<Boolean> = _overlayGranted.asStateFlow()

    private val _notificationsGranted = MutableStateFlow(false)
    val notificationsGranted: StateFlow<Boolean> = _notificationsGranted.asStateFlow()

    private val _batteryIgnored = MutableStateFlow(false)
    val batteryIgnored: StateFlow<Boolean> = _batteryIgnored.asStateFlow()

    fun refreshPermissions() {
        val context = getApplication<Application>()
        _accessibilityGranted.value = Permissions.isAccessibilityEnabled(context)
        _overlayGranted.value = Permissions.canDrawOverlays(context)
        _notificationsGranted.value = Permissions.notificationsGranted(context)
        _batteryIgnored.value = Permissions.isIgnoringBatteryOptimizations(context)
    }

    /**
     * Live checks: the cached values can be stale after an app update or when the user toggles
     * accessibility in system settings while the app stays in the foreground.
     */
    fun isAccessibilityReady(): Boolean {
        val context = getApplication<Application>()
        val live = Permissions.isAccessibilityEnabled(context)
        if (live != _accessibilityGranted.value) _accessibilityGranted.value = live
        return live
    }

    fun isOverlayReady(): Boolean {
        val context = getApplication<Application>()
        val live = Permissions.canDrawOverlays(context)
        if (live != _overlayGranted.value) _overlayGranted.value = live
        return live
    }

    fun savePendingMacro(name: String) {
        val pending = RecorderController.pendingMacro.value ?: return
        container.macroRepository.save(pending.events, name.trim().ifEmpty { defaultMacroName() })
        RecorderController.clearPending()
    }

    fun dismissPendingMacro() = RecorderController.clearPending()

    fun deleteMacro(id: String) = container.macroRepository.delete(id)

    fun renameMacro(id: String, name: String) = container.macroRepository.rename(id, name.trim())

    suspend fun exportMacro(id: String): String? = withContext(Dispatchers.IO) {
        container.macroRepository.exportMacro(id)
    }

    suspend fun exportAll(): String = withContext(Dispatchers.IO) {
        container.macroRepository.exportAll()
    }

    suspend fun importText(text: String): Int = withContext(Dispatchers.IO) {
        container.macroRepository.importText(text)
    }

    fun updatePreset(config: PresetConfig) = container.presetRepository.update(config)

    fun setJitter(px: Float) {
        viewModelScope.launch { container.settingsRepository.setJitter(px) }
    }

    fun playMacro(macro: Macro, repeat: Int, intervalMs: Long, speed: Float, jitterPx: Float) {
        PlaybackEngine.start(
            PlaybackSpec(
                label = macro.name,
                events = macro.events,
                delayMs = 0,
                repeat = repeat,
                intervalMs = intervalMs,
                speed = speed,
                jitterPx = jitterPx,
            ),
        )
        OverlayService.start(getApplication(), OverlayService.ACTION_CONTROL)
    }

    fun playPreset(config: PresetConfig, jitterPx: Float) {
        val app = getApplication<Application>()
        val label = app.getString(presetLabelRes(config.type))
        PlaybackEngine.start(
            PlaybackSpec(
                label = label,
                events = PresetEngine.buildIteration(config),
                delayMs = config.delayMs,
                repeat = config.repeat,
                intervalMs = config.intervalMs,
                speed = config.speed,
                jitterPx = jitterPx,
            ),
        )
        OverlayService.start(app, OverlayService.ACTION_CONTROL)
    }

    fun stopPlayback() = PlaybackEngine.stop()

    fun stopRecording() = RecorderController.stop()

    fun cancelRecording() = RecorderController.cancel()

    private fun presetLabelRes(type: PresetConfig.PresetType): Int = when (type) {
        PresetConfig.PresetType.SINGLE_TAP -> R.string.preset_single_tap
        PresetConfig.PresetType.MULTI_TAP -> R.string.preset_multi_tap
        PresetConfig.PresetType.DOUBLE_TAP -> R.string.preset_double_tap
        PresetConfig.PresetType.LONG_PRESS -> R.string.preset_long_press
        PresetConfig.PresetType.SWIPE -> R.string.preset_swipe
    }

    private fun defaultMacroName(): String {
        val app = getApplication<Application>()
        val date = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault())
            .format(java.util.Date())
        return app.getString(R.string.macro_default_name, date)
    }
}
