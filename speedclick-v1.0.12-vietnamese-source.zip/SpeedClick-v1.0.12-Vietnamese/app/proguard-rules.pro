# kotlinx.serialization
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
-keep,includedescriptorclasses class com.speedclick.app.**$$serializer { *; }
-keepclassmembers class com.speedclick.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.speedclick.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
# Keep the whole data model to guarantee kotlinx.serialization codegen survives shrinking.
-keep class com.speedclick.app.data.** { *; }
