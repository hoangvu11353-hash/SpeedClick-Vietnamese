# SpeedClicker · 极速连点

> 免费、无广告、不联网的 Android 连点器：悬浮窗录制宏 + 无障碍手势回放 + 五类系统预设。
> A free, ad-free, offline Android auto-clicker: record macros from a floating overlay, replay them
> through accessibility gestures, or use one of five built-in presets.

[![Platform](https://img.shields.io/badge/Android-11–17-3DDC84?logo=android&logoColor=white)](#系统要求--requirements)
[![Kotlin](https://img.shields.io/badge/Kotlin-2.2-7F52FF?logo=kotlin&logoColor=white)](https://kotlinlang.org)
[![Compose](https://img.shields.io/badge/Jetpack%20Compose-Material%203-4285F4?logo=jetpackcompose&logoColor=white)](https://developer.android.com/jetpack/compose)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

---

## 简介 · Intro

**中文**：极速连点是一款不需要 Root 的安卓连点器。它只申请「无障碍服务」和「悬浮窗」两项权限，
不申请网络权限，不收集任何数据。你可以在悬浮窗里手动录制一段宏（点击、滑动、多指操作都支持），
也可以用内置的五类系统预设（单点连点 / 多点连点 / 双击 / 长按 / 滑动）直接开工，
参数（延时启动、循环次数、循环间隔、倍速）都可以在运行时随时调整。

**English**: SpeedClicker is a root-free Android auto-clicker. It needs nothing but the accessibility
service and the "display over other apps" permission — no network permission, no analytics, no ads.
Record a macro from the floating overlay (taps, swipes and multi-finger gestures are all captured),
or start immediately with one of five presets (single tap / multi tap / double tap / long press /
swipe). Delay, repeat count, interval and playback speed are adjustable at any time.

## 功能 · Features

| 中文 | English |
| --- | --- |
| **悬浮窗录制**：全屏透明层采集原始触摸（DOWN/MOVE/UP、多指 pointerId、相对时间戳），坐标归一化为 0–1，跨分辨率回放一致 | **Overlay recording**: a full-screen transparent layer samples raw touches (DOWN/MOVE/UP, per-pointer ids, relative timestamps); coordinates are normalized to 0–1 so playback matches on any resolution |
| **无障碍回放**：按运行时 `getMaxGestureDuration()` / `getMaxStrokeCount()` 自动切分手势，多指录制映射为并行笔画 | **Accessibility playback**: gestures are chunked against the runtime limits; multi-finger recordings become parallel strokes |
| **五类系统预设**：单点 / 多点（2–4 指）/ 双击 / 长按 / 滑动，用悬浮靶心拾取坐标 | **Five presets**: single tap, multi tap (2–4 fingers), double tap, long press, swipe — pick coordinates with the floating crosshair |
| **悬浮控制**：悬浮球 + 控制条（运行中状态 + 暂停 / 停止 / 隐藏），通知栏也有暂停 / 停止动作 | **Floating controls**: ball + control bar (running state, pause / stop / hide) plus notification actions |
| **宏管理**：本地 JSON 存储、重命名、导入导出（SAF 文档选择器） | **Macro library**: JSON files on device, rename, import/export through the system file picker |
| **设置**：跟随系统语言（简体中文 / English / Tiếng Việt）、随机偏移（拟人抖动）、电池优化引导 | **Settings**: system language (简体中文 / English / Tiếng Việt), random offset jitter, battery-optimization shortcut |
| **稳定性细节**：暂停不补偿、卡顿不补点、手势回调超时、派发被拒时退避重试 | **Robustness**: pausing never replays skipped cycles, a stalled process cannot burst, lost gesture callbacks time out, rejected dispatches back off and retry |

## 截图 · Screenshots

| 预设参数 / Preset | 宏列表 / Macros | 录制面板 / Record panel |
| --- | --- | --- |
| ![preset](docs/screenshots/ui/single-dialog.png) | ![macros](docs/screenshots/ui/macros-tab.png) | ![record](docs/screenshots/ui/record-panel.png) |

| 悬浮控制条 / Control bar | 多指回放 / Multi-finger | 通知栏 / Notification |
| --- | --- | --- |
| ![overlay](docs/screenshots/ui/overlay-controlbar.png) | ![multi](docs/screenshots/ui/multi-running.png) | ![notif](docs/screenshots/ui/notif-shade.png) |

更多截图 / More: `docs/screenshots/ui/`（界面与模拟器实测流程）、`docs/screenshots/overlay/`（悬浮层各状态渲染）、
`docs/screenshots/compat/`（8 种屏幕比例 + 深色模式 + 大字体渲染矩阵）、
`docs/screenshots/res/`（同一设备切换 6 种分辨率/密度/比例的实机截图）。

## 系统要求 · Requirements

- Android 11 – 17（API 30 – 37），`minSdk 30` / `targetSdk 37`
- 无需 Root，无需 Shizuku；需要手动开启「无障碍服务」与「悬浮窗」权限
- 与屏幕尺寸无关：内容有最大宽度限制并居中，横屏 / 平板 / 折叠屏都不会被拉伸

## 安装 · Install

1. 下载 `speedclick-vX.Y.Z-release.apk` 传到手机安装（或自行构建）。
2. 打开应用，按首页引导依次开启：无障碍服务 → 悬浮窗 → 通知（Android 13+）→ 电池优化（建议）。
3. Android 13+ 侧载安装时若「无障碍」开关是灰的：应用信息 → 右上角「允许受限设置」→ 再回来开启。
4. Android 16/17 若开启了「高级保护模式」，系统会禁用本应用的无障碍服务，需要先在系统设置里关闭该模式。
5. 不要用系统设置里的「强行停止」结束应用——那会同时撤销无障碍授权（平台行为）。日常停止请用应用内「停止」。

## 构建 · Build

前置：JDK 17+、Android SDK（`platforms;android-37.0`、`build-tools;37.0.0`）。

```bash
# 1. 配置 SDK 路径 local.properties: sdk.dir=/path/to/Android/Sdk

# 2. （可选）配置签名；不配置也能构建，只是 release APK 未签名
#    keystore.properties:
#      storeFile=speedclick-release.jks
#      storePassword=******
#      keyAlias=speedclick
#      keyPassword=******

# 3. 构建
gradlew.bat assembleRelease      # 产物 app/build/outputs/apk/release/
gradlew.bat testDebugUnitTest    # 单元测试（Robolectric）
gradlew.bat :app:lintDebug       # 静态检查
```

> 仓库不包含签名密钥。可用
> `keytool -genkeypair -keystore speedclick-release.jks -alias speedclick -keyalg RSA -keysize 2048 -validity 10000`
> 生成自己的密钥；已发布的版本只能用首次使用的密钥继续升级。
> This repository ships **no signing key** — generate your own with the command above.

## 测试 · Tests

三层共 **81 项** 自动化测试，全部在 JVM 上运行（Robolectric），另有真机与模拟器实测记录：

- 纯逻辑：手势分块与跨窗口路径插值、触控采样与抽稀、预设事件生成、JSON 兼容与版本迁移
- JVM 上的真实运行：端到端回放（分块派发 → 无障碍回调 → 循环 / 暂停 / 恢复 / 停止）、
  暂停不补偿错过的循环、长时间卡顿不产生补点风暴、丢失回调必须结束会话、派发被拒要退避重试、
  悬浮服务与通知、30 分钟录制上限、权限状态判定
- 界面渲染：首页 / 主框架 / 宏 / 预设 / 设置的截图测试，8 种屏幕比例 + 深色模式 + 大字体矩阵，
  以及可点击元素 ≥44dp 的断言；渲染矩阵显式固定 `en-rUS` 与 `zh-rCN` 两套语言，
  并带「空白渲染即失败」断言（预设弹窗改为捕获 Dialog 自己的窗口，否则画出来是空白）

实测记录（数字来自真机日志与截图对比）：

| 场景 | 结果 |
| --- | --- |
| Android 17 真机 · 单点最高频 30s | 810 次派发 ≈ 26.8 次/秒，严格线性，0 重试 0 失败 0 ANR |
| Android 17 真机 · 多点（2 指）20s | 531 次 ≈ 26.6 次/秒，全部双指手势，0 失败 |
| Android 17 真机 · 连续 120s | 内存 60–62MB 稳定不涨，电池温度 33.1°C 不变 |
| Android 17 真机 · 快速启停 5 轮 | 5/5 恢复，0 失败 0 ANR |
| Android 12 模拟器 · 跨应用投递 | 31.7 秒内 355 次点击投递到另一个应用，投递率 100%，节拍 p50 90ms |
| Android 12 模拟器 · 9 种分辨率/比例 | 1920×1080@280、1280×720@320、2400×1080@440、3200×1440@560、1024×600@240、2560×1600@320、1200×1200@360（1:1）、1080×2160@420（1:2）、2520×1080@420（21:9）全通过；拾取点与回放点误差 0–15px，每种配置 59–61 次派发 0 失败 |
| Android 12 模拟器 · 深色模式 + 1.3× 字体 | 两档配置下四个页面与预设弹窗均无裁切、无重叠 |
| Android 12 模拟器 · 预设类型 × 分辨率 | 多点连点（2 指）在 4 档分辨率下均为 strokes=2 且两指坐标与拾取点一致；滑动在 3 档下均为单笔画 points=3，起终点一致；全部 0 失败 |
| Android 12 模拟器 · 数据管理 | 导出全部宏生成合法 JSON（schemaVersion 1，归一化坐标）；同 id 导入自动合并、新 id 导入新增一条；删除有二次确认 |
| Android 12 模拟器 · 服务被系统断开 | 会话在约 1 秒内优雅结束（不卡死、无 ANR、进程存活），重新启用后可再次回放 |
| 五类预设 × 分辨率 | 单点 9 档、多点 4 档、滑动 3 档、长按 2 档（duration=800ms）、双击 1 档（两次 start 相隔 120ms）全部实测通过 |
| Android 17 真机 · 长按 / 快速启停 | 长按 15 次/8 秒（0 失败）；快速启停 5/5 成功、0 失败 0 ANR |
| Android 17 真机 · 5 分钟长稳 | 7436 次点击（≈24.4 次/秒，严格线性），电池 32.4–32.5°C 恒定，内存 61–66MB 无增长，0 失败 0 重试 0 ANR |
| Android 12 模拟器 · 通知栏控制 | 暂停冻结（文案变「已暂停」）、继续按原节奏恢复、停止归零，0 失败 |
| Android 12 模拟器 · 宏卡片菜单 | 重命名立即生效；单卡导出生成合法 JSON；删除有二次确认 |
| Android 12 模拟器 · 异常导入 | 截断 JSON 提示「导入失败」；空文件安全失败；schemaVersion=999 前向兼容导入；三种情况均不崩溃、列表不变 |
| Android 15 模拟器 · 1.0.11 对等复测 | 单点 132 次/10 秒、多点 84 次/10 秒（全双指）；快速启停 5/5；120 秒内存 36→40MB 后持平，1361 次派发 0 失败 |
| Android 17 真机 · 录制/回放一致性 | 修复前录 (300,250) 回放成 (300,109)（悬浮层内缩 40dp）；改用屏幕原始坐标后，真机与模拟器的录制—回放落点均与输入完全一致 |
| Android 12 模拟器 · 1.0.12 投递复测 | 单点预设下探针收到 171 次触摸，坐标与预设点减去状态栏高度完全吻合；真机多点 275 次/8 秒全为双指手势 |
| Android 15 模拟器 · 1.0.12 | 单点 131 次/10 秒、多点 84 次/10 秒（全双指），0 重试 0 失败 |
| Android 12 模拟器 · 跨分辨率回放 | 同一宏在 1920×1080 / 2400×1080 / 1280×720 下回放，落点 x 精确按 900→1125→600 缩放 |
| Android 15 模拟器 · 3 档密度 | 240 / 280 / 440 dpi（1280×720dp / 1097×617dp / 698×393dp）各约 131 次/10 秒，0 重试 0 失败 |

## 设计要点 · Design notes

- **不加网络权限**：应用没有 `INTERNET` 权限，无法联网，也不收集数据。
- **回放节奏**：每一轮按绝对时间轴调度；暂停会把暂停时长从时间轴里扣掉，
  进程被系统冻结导致落后超过 250ms 时重新对表——两者都是为了避免「补点风暴」。
- **屏幕尺寸**：每轮回放都重新读取当前显示尺寸（`WindowManager.currentWindowMetrics`），
  所以旋转、分屏拖动、折叠屏展开后落点仍按比例正确，不需要重启回放。
- **手势边界**：按 `GestureDescription` 的运行时上限切分（通常单手势 ≤60s、≤10 笔画）。
- **前台服务**：API 34+ 使用 `specialUse` 类型并声明 `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`，API 30–33 走无类型兼容路径。
- **测试方法学**：`uiautomator dump` 会接管无障碍连接并把本应用的服务挤掉，因此稳定性脚本在回放期间
  只用 logcat / 截图 / `dumpsys`；adb 注入的点击在回放进行中会被系统丢弃，悬浮控制条的暂停/继续由
  单元测试与模拟器真机流程覆盖。

## 已知限制 · Known limitations

- 部分游戏的反作弊系统可能检测自动点击，请自行判断使用场景。
- Android 16/17 开启「高级保护模式」后，系统会禁用第三方无障碍服务，应用内只能提示、无法绕过。
- 部分新模拟器把每个应用放在独立虚拟显示上，而无障碍手势只能作用于自身所在显示，回放可能点不到其它应用。

## 隐私 · Privacy

中文：本应用不申请网络权限，所有宏与设置都保存在应用私有目录，不会上传任何数据。

English: SpeedClicker has no network permission. Macros and settings live in the app's private
storage; nothing is ever uploaded.

## 许可 · License

[MIT](LICENSE)
